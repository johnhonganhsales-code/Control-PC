# CAI DAT 1 FILE - MAY AO 1 (cai BEN TRONG may ao)
# Cach chay: mo PowerShell bang quyen Administrator (chuot phai > Run as administrator), dan:
#   powershell -ExecutionPolicy Bypass -File "<duong dan toi file nay>"
# File nay chua SAN toan bo script cua may nay, khong can file nao khac.
# Trong file co POLL_KEY that: KHONG dua len mang, KHONG gui cho nguoi la.
$ErrorActionPreference = "Stop"
$dst = "C:\Scripts"
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) { Write-Host "LOI: hay mo PowerShell bang Run as administrator roi chay lai."; exit 1 }
New-Item -ItemType Directory -Force $dst | Out-Null
try { Add-MpPreference -ExclusionPath $dst; Write-Host "OK: da them ngoai le antivirus cho $dst" }
catch { Write-Host "CANH BAO: khong them duoc ngoai le. Neu dung antivirus khac, tu them $dst vao Exclusions." }

$token = (Read-Host "Dan BOT TOKEN (dang 123456789:ABC...)").Trim().Trim('"')
if ($token -notmatch '^\d+:[\w-]+$') { Write-Host "LOI: token sai (phai co dau hai cham giua). Chay lai."; exit 1 }
function Esc($v) { $v.Replace('`','``').Replace('"','`"').Replace('$','`$') }
$pingurl = (Read-Host "Dan URL ping RIENG cua may nay (Healthchecks.io > check cua may nay > Copy Ping URL). Enter de bo qua").Trim().Trim('"')
$skipHc = $false
if ($pingurl -eq "") { $skipHc = $true; Write-Host "CANH BAO: bo qua Healthchecks cho may nay (sau nay chay lai file cai dat de them)." }
elseif ($pingurl -notmatch '^https://hc-ping\.com/\S+$') { Write-Host "LOI: URL ping phai dang https://hc-ping.com/... Chay lai."; exit 1 }

$files = [ordered]@{}
$files["telegram-screenshot-listener.ps1"] = @'
# Nghe lenh chup man hinh + tat may qua Telegram/Worker - CHAY TREN MOI MAY CAN CHUP
# Dat file nay vao C:\Scripts\telegram-screenshot-listener.ps1 tren TUNG may.
# Cach dung: trong nhom MY PC hoac trong app "May cua Tien", gui:
#   /chupmanhinh <ten may>
#   /tatmay <ten may>      (shutdown may, sau 10 giay)
#   /khoidonglai <ten may> (restart may, sau 10 giay)
#   /batmay <ten may>      (Wake-on-LAN: chi may $WolSender gui goi bat)
# Vi du: /chupmanhinh May chinh cty
# Chi may co $MyName trung ten do moi chup va gui anh ve nhom.
# BAN ASCII, KHONG DAU, KHONG EMOJI.
# QUAN TRONG: script nay PHAI chay duoi user dang dang nhap (qua Startup),
# KHONG chay duoi SYSTEM - SYSTEM khong co desktop nen chup ra anh den.

$BotToken = "PASTE_TOKEN_HERE"      # <-- copy token y het trong telegram-pc-status-7may.ps1
$ChatId   = "-5189532438"           # <-- nhom MY PC
$AllowedUserId = 1444024297         # <-- chi nhan lenh tu Tien
$QueueUrl = "https://may-cua-tien.john-honganh-sales.workers.dev"   # <-- URL Worker
$PollKey  = "uYbFf864IVNooZhIw94n8jGCciewXe7Y"                    # <-- giong secret POLL_KEY
$MyName = "May ao 1"        # <-- SUA: ten may nay, giong het ten check
                                    # tren Healthchecks, vi du: May chinh cty
                                    # So sanh khong phan biet hoa/thuong.

$ScriptDir = "C:\Scripts"
$LogFile = "$ScriptDir\screenshot-telegram.log"
$OffsetFile = "$ScriptDir\screenshot-offset-queue.txt"

# Bat may tu xa bang Wake-on-LAN. Chi may co ten $WolSender (may luon bat) moi gui goi bat.
# Cac may khac cung chay file nay nhung bo qua lenh /batmay.
$WolSender = "may phu nha"
$WolTargets = @{ "may chinh nha" = "EC-D6-8A-DE-87-7A" }   # MAC may chinh nha (lay tu wol-telegram-listener.ps1 dang chay duoc)
$WolBroadcast = "192.168.68.255"                            # broadcast mang LAN nha (IP 192.168.68.x)
$ShotFile = "$env:TEMP\screenshot.jpg"

function Write-Log($msg) {
    $time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$time $msg" | Out-File -FilePath $LogFile -Append -Encoding UTF8
}

# Chong chay trung 2 tien trinh (vu WoL v3 da bi trung 2 tin).
# Mutex giu suot luc script chay, tien trinh thu 2 thay da co thi thoat ngay.
$Mutex = New-Object System.Threading.Mutex($false, "Global\TelegramScreenshotListener")
if (-not $Mutex.WaitOne(0)) { exit }

function Invoke-Tg($Method, $BodyObj) {
    $json = $BodyObj | ConvertTo-Json -Depth 5 -Compress
    try {
        $r = Invoke-RestMethod -Uri "https://api.telegram.org/bot$BotToken/$Method" `
            -Method Post -ContentType "application/json" -Body $json `
            -TimeoutSec 10 -ErrorAction Stop
        return $r
    } catch {
        $detail = $_.ErrorDetails.Message
        if (-not $detail) { $detail = $_.Exception.Message }
        Write-Log "$Method LOI: $detail"
        return $null
    }
}

function Send-Telegram($Text) {
    $r = Invoke-Tg "sendMessage" @{ chat_id = $ChatId; text = $Text }
    return ($null -ne $r)
}

function Take-Screenshot() {
    try {
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        $bounds = [System.Windows.Forms.SystemInformation]::VirtualScreen
        $bmp = New-Object System.Drawing.Bitmap($bounds.Width, $bounds.Height)
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
        $g.Dispose()
        # Luu JPEG chat luong 70 cho nhe (vai tram KB).
        $codec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() |
            Where-Object { $_.MimeType -eq "image/jpeg" }
        $params = New-Object System.Drawing.Imaging.EncoderParameters(1)
        $params.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter(
            [System.Drawing.Imaging.Encoder]::Quality, [long]70)
        $bmp.Save($ShotFile, $codec, $params)
        $bmp.Dispose()
        if (Test-Path $ShotFile) { return $ShotFile }
        Write-Log "Chup xong nhung khong thay file $ShotFile"
        return $null
    } catch {
        Write-Log "Chup man hinh LOI: $($_.Exception.Message)"
        return $null
    }
}

function Send-Photo($FilePath, $Caption) {
    # Dung curl.exe co san tren Windows 10/11 de gui multipart/form-data.
    # PowerShell 5.1 khong co Invoke-RestMethod -Form nen khong dung cach do.
    $curl = "$env:SystemRoot\System32\curl.exe"
    if (-not (Test-Path $curl)) { $curl = "curl.exe" }
    try {
        $out = & $curl -s --max-time 30 `
            -F "chat_id=$ChatId" `
            -F "caption=$Caption" `
            -F "photo=@$FilePath" `
            "https://api.telegram.org/bot$BotToken/sendPhoto" 2>&1
        if ($out -match '"ok":true') { return $true }
        Write-Log "Gui anh LOI, Telegram tra: $out"
        return $false
    } catch {
        Write-Log "Gui anh LOI: $($_.Exception.Message)"
        return $false
    }
}

function Send-Wol($Mac) {
    $hex = ($Mac -replace '[^0-9A-Fa-f]', '')
    if ($hex.Length -ne 12) { return $false }
    $macBytes = for ($i = 0; $i -lt 12; $i += 2) { [Convert]::ToByte($hex.Substring($i, 2), 16) }
    $packet = [byte[]](@(0xFF) * 6 + $macBytes * 16)
    $udp = New-Object System.Net.Sockets.UdpClient
    try {
        $udp.EnableBroadcast = $true
        # Gui 3 dot cach nhau 4 giay (giong cach wol-telegram-listener.ps1 gui nhieu lan cho chac).
        for ($n = 1; $n -le 3; $n++) {
            foreach ($ip in @($WolBroadcast, "255.255.255.255")) {
                foreach ($port in @(9, 7)) { [void]$udp.Send($packet, $packet.Length, $ip, $port) }
            }
            if ($n -lt 3) { Start-Sleep -Seconds 4 }
        }
    } finally { $udp.Close() }
    return $true
}

Write-Log "Screenshot listener khoi dong, may=$MyName"

function Upload-Shot($path) {
    try {
        $m = [uri]::EscapeDataString($MyName.ToLower())
        Invoke-RestMethod -Uri "$QueueUrl/shot?machine=$m" -Method Post -Headers @{ "X-Poll-Key" = $PollKey } -InFile $path -ContentType "image/jpeg" -TimeoutSec 60 | Out-Null
        Write-Log "Da gui anh len web"
    } catch { Write-Log "Gui anh len web LOI: $($_.Exception.Message)" }
}
$Offset = 0
if (Test-Path $OffsetFile) {
    $saved = Get-Content $OffsetFile -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($saved -match '^\d+$') { $Offset = [int64]$saved }
}

# Xu ly 1 lenh (dung chung cho WebSocket va HTTP poll). Bo qua lenh da xu ly (update_id < Offset).
function Process-Update($upd) {
    if ([int64]$upd.update_id -lt $script:Offset) { return }
            $script:Offset = [int64]$upd.update_id + 1
            $script:Offset | Out-File -FilePath $OffsetFile -Encoding ascii -Force

            if (-not $upd.message -or -not $upd.message.text) { return }
            $txt = $upd.message.text.Trim()
            $who = $upd.message.from.id
            $chat = $upd.message.chat.id

            # Chi nhan lenh trong nhom MY PC, tu dung Tien.
            if ([string]$chat -ne [string]$ChatId) { return }
            if ([string]$who -ne [string]$AllowedUserId) { return }

            # /batmay <ten may>: chi may $WolSender gui goi Wake-on-LAN. Bo qua lenh cu hon 2 phut.
            if ($txt -match '^/batmay(@\w+)?\s+(.+)$') {
                $wTarget = $Matches[2].Trim().ToLower()
                if ($MyName.ToLower() -ne $WolSender.ToLower()) { return }
                $nowMs = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
                if (($nowMs - [int64]$upd.update_id) -gt 120000) {
                    Write-Log "Bo qua lenh batmay cu (qua 2 phut)"
                    return
                }
                if (-not $WolTargets.ContainsKey($wTarget)) {
                    Write-Log "batmay: '$wTarget' chua co trong WolTargets"
                    Send-Telegram "May $MyName chua biet dia chi MAC cua '$wTarget'. Dien vao WolTargets trong telegram-screenshot-listener.ps1."
                    return
                }
                if (Send-Wol $WolTargets[$wTarget]) {
                    Write-Log "batmay: da gui goi Wake-on-LAN toi $wTarget"
                    Send-Telegram "May $MyName da gui lenh bat toi $wTarget. Doi khoang 30-60 giay."
                } else {
                    Write-Log "batmay: dia chi MAC cua $wTarget khong hop le"
                    Send-Telegram "Dia chi MAC cua $wTarget trong WolTargets khong hop le (can dang AA-BB-CC-DD-EE-FF)."
                }
                return
            }

            # Lenh la /chupmanhinh, /tatmay hoac /khoidonglai <ten may>, co the kem @ControlPCofTienbot.
            if ($txt -notmatch '^/(chupmanhinh|tatmay|khoidonglai)(@\w+)?(\s+(.+))?$') { return }
            $cmd = $Matches[1]
            $target = ""
            if ($Matches[4]) { $target = $Matches[4].Trim() }
            Write-Log "Nhan lenh $cmd target='$target' tu user=$who"
            if ($target -eq "") { return }
            if ($target.ToLower() -ne $MyName.ToLower()) { return }

            # TAT MAY: shutdown sau 10 giay. Bo qua lenh cu hon 2 phut de tranh
            # tat nham khi may vua bat lai (update_id chinh la moc thoi gian ms).
            if ($cmd -eq "tatmay") {
                $nowMs = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
                if (($nowMs - [int64]$upd.update_id) -gt 120000) {
                    Write-Log "Bo qua lenh tatmay cu (qua 2 phut)"
                    return
                }
                Write-Log "Thuc hien TAT MAY $MyName"
                Send-Telegram "May $MyName se tat sau 10 giay."
                & "$env:SystemRoot\System32\shutdown.exe" /s /f /t 10 /c "Tat may tu app May cua Tien"
                return
            }

            # KHOI DONG LAI: restart sau 10 giay. Cung bo qua lenh cu hon 2 phut.
            if ($cmd -eq "khoidonglai") {
                $nowMs = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
                if (($nowMs - [int64]$upd.update_id) -gt 120000) {
                    Write-Log "Bo qua lenh khoidonglai cu (qua 2 phut)"
                    return
                }
                Write-Log "Thuc hien KHOI DONG LAI $MyName"
                Send-Telegram "May $MyName se khoi dong lai sau 10 giay."
                & "$env:SystemRoot\System32\shutdown.exe" /r /f /t 10 /c "Khoi dong lai tu app May cua Tien"
                return
            }

            $file = Take-Screenshot
            if ($file) {
                $time = Get-Date -Format "HH:mm:ss dd-MM-yyyy"
                Upload-Shot $file
                $ok = Send-Photo $file "Man hinh $MyName - $time"
                if ($ok) { Write-Log "Da gui anh man hinh $MyName" }
            } else {
                Send-Telegram "May $MyName chup man hinh LOI, xem log C:\Scripts\screenshot-telegram.log"
            }
}

# --- WebSocket toi Worker (Durable Object): nhan lenh tuc thi. HTTP /poll chi con la du phong. ---
$script:Ws = $null; $script:WsTask = $null; $script:WsText = ""; $script:WsFails = 0
$script:WsBuf = New-Object byte[] 16384
$script:WsLastPing = Get-Date; $script:WsLastTry = [DateTime]::MinValue
$WsUrl = ($QueueUrl -replace '^http', 'ws').TrimEnd('/') + "/ws?machine=" + [uri]::EscapeDataString($MyName.ToLower())

function Ws-Close {
    if ($script:Ws) { try { $script:Ws.Dispose() } catch {} }
    $script:Ws = $null; $script:WsTask = $null; $script:WsText = ""
}

function Ws-Connect {
    $script:WsLastTry = Get-Date
    try {
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
        $c = New-Object System.Net.WebSockets.ClientWebSocket
        $c.Options.SetRequestHeader("X-Poll-Key", $PollKey)
        if (-not $c.ConnectAsync([Uri]$WsUrl, [Threading.CancellationToken]::None).Wait(10000)) {
            $c.Dispose(); $script:WsFails++
            if ($script:WsFails -le 2) { Write-Log "WS: ket noi qua han, dung HTTP poll du phong" }
            return
        }
        $script:Ws = $c
        $script:WsFails = 0
        $script:WsLastPing = Get-Date
        $script:WsTask = $c.ReceiveAsync([ArraySegment[byte]]::new($script:WsBuf), [Threading.CancellationToken]::None)
        Write-Log "WS: da ket noi"
    } catch {
        $script:WsFails++
        if ($script:WsFails -le 2) { Write-Log ("WS: khong ket noi duoc: " + $_.Exception.Message + " (dung HTTP poll du phong)") }
        Ws-Close
    }
}

# Moi lan goi: toi da ~1 giay cho tin nhan WebSocket; xu ly lenh neu co; gui ping giu ket noi.
function Ws-Tick {
    if (-not $script:Ws) {
        $wait = [Math]::Min(300, 20 * [Math]::Pow(2, [Math]::Min($script:WsFails, 4)))
        if (((Get-Date) - $script:WsLastTry).TotalSeconds -ge $wait) { Ws-Connect }
        if (-not $script:Ws) { Start-Sleep -Seconds 1; return }
    }
    try {
        if ($script:Ws.State -ne [System.Net.WebSockets.WebSocketState]::Open) { throw "WS khong con mo" }
        if ($script:WsTask.Wait(1000)) {
            $r = $script:WsTask.Result
            if ($r.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) { throw "WS bi dong" }
            $script:WsText += [Text.Encoding]::UTF8.GetString($script:WsBuf, 0, $r.Count)
            $msg = $null
            if ($r.EndOfMessage) { $msg = $script:WsText; $script:WsText = "" }
            $script:WsTask = $script:Ws.ReceiveAsync([ArraySegment[byte]]::new($script:WsBuf), [Threading.CancellationToken]::None)
            if ($msg -and $msg -ne "pong") {
                try { Process-Update ($msg | ConvertFrom-Json) }
                catch { Write-Log ("Xu ly lenh WS LOI: " + $_.Exception.Message) }
            }
        }
        if (((Get-Date) - $script:WsLastPing).TotalSeconds -ge 25) {
            $script:WsLastPing = Get-Date
            [void]$script:Ws.SendAsync([ArraySegment[byte]]::new([Text.Encoding]::UTF8.GetBytes("ping")), [System.Net.WebSockets.WebSocketMessageType]::Text, $true, [Threading.CancellationToken]::None).Wait(5000)
        }
    } catch {
        Write-Log ("WS: mat ket noi (" + $_.Exception.Message + "), dung HTTP poll du phong")
        Ws-Close
    }
}

# Vong chinh: WebSocket la duong chinh. Khi WS dang noi, HTTP poll 60 giay/lan de du phong; khi WS mat, 15 giay/lan nhu cu.
$LastPoll = [DateTime]::MinValue
while ($true) {
    Ws-Tick
    $gap = 15; if ($script:Ws) { $gap = 60 }
    if (((Get-Date) - $LastPoll).TotalSeconds -ge $gap) {
        $LastPoll = Get-Date
        try {
            # Lay lenh tu Worker (hang doi), khong dung getUpdates cua Telegram nua.
            $resp = Invoke-RestMethod -Uri "$QueueUrl/poll?since=$Offset" -Headers @{ "X-Poll-Key" = $PollKey } -TimeoutSec 15 -ErrorAction Stop
            foreach ($upd in $resp.result) { Process-Update $upd }
        } catch {
            Write-Log "Poll LOI: $($_.Exception.Message)"
            Start-Sleep -Seconds 5
        }
    }
}
'@
$files["setup-screenshot-listener.ps1"] = @'
# Cai dat listener chup man hinh - chay 1 lan tren MOI may can chup.
# KHONG can quyen Admin (chi ghi vao Startup cua user hien tai).
# Listener chay duoi user dang dang nhap, qua Startup, de chup duoc desktop.
# Neu chay duoi SYSTEM thi chup ra anh den, nen KHONG dung Task Scheduler SYSTEM.
# BAN ASCII, KHONG DAU, KHONG EMOJI.

$ScriptDir = "C:\Scripts"
$Listener = "$ScriptDir\telegram-screenshot-listener.ps1"
$StartupDir = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"
$Launcher = "$StartupDir\telegram-screenshot.bat"

if (-not (Test-Path $Listener)) {
    Write-Host "LOI: Khong thay $Listener"
    Write-Host "Copy file telegram-screenshot-listener.ps1 vao C:\Scripts\ truoc."
    exit 1
}

# Kiem tra da dien token + ten may chua.
$content = Get-Content $Listener -Raw
if ($content.Contains('PASTE_TOKEN' + '_HERE')) {
    Write-Host "LOI: Chua dien `$BotToken trong $Listener"
    Write-Host "Mo file bang Notepad, copy token y het trong telegram-pc-status-7may.ps1 roi chay lai."
    exit 1
}
if ($content -match 'THAY-TEN-MAY-NAY') {
    Write-Host "LOI: Chua dien `$MyName trong $Listener"
    Write-Host "Sua thanh ten may nay, giong het ten check tren Healthchecks, vi du: May chinh cty"
    exit 1
}

# Tao file bat trong Startup de listener tu chay moi lan dang nhap.
$bat = '@echo off' + [Environment]::NewLine +
    'start "" /min powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "C:\Scripts\telegram-screenshot-listener.ps1"' + [Environment]::NewLine
$bat | Out-File -FilePath $Launcher -Encoding ascii -Force
Write-Host "OK: Da tao $Launcher"

# Chay listener ngay, khong can dang xuat / khoi dong lai.
# Neu da chay roi thi tien trinh moi se tu thoat nho mutex trong script.
Start-Process -FilePath "powershell.exe" `
    -ArgumentList "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$Listener`"" `
    -WindowStyle Hidden
Start-Sleep -Seconds 5
Write-Host "OK: Da khoi dong listener. Doi 5 giay roi test:"
Write-Host "  Gui vao nhom MY PC: /chupmanhinh <ten may nay>"
Write-Host "  Anh man hinh phai ve nhom trong vong ~10 giay."
Write-Host "  Neu khong thay anh, mo file C:\Scripts\screenshot-telegram.log xem loi."
Write-Host "Ghi chu: de go listener, xoa file $Launcher roi khoi dong lai may."
'@
$files["fetch-runchoice.ps1"] = @'
# Lay che do + tai khoan tu app "May cua Tien" ngay luc may ao khoi dong.
# CHAY TRONG MAY AO (khach), TRUOC khi bot doc C:\Scripts\runchoice.txt.
# Dat file nay vao C:\Scripts\fetch-runchoice.ps1 trong MOI may ao, roi sua 2 dong
# $VmName va $PollKey ben duoi. Sau do goi no o dau script khoi dong bot (xem huong dan).
#
# Cach hoat dong: hoi Worker xem app dang chon che do + tai khoan nao cho may ao nay,
# ghi vao C:\Scripts\runchoice.txt (2 dong: mode=<1-10>, acc=<ten tai khoan>) dung
# dinh dang ma bot trong may ao dang doc. Khong lay duoc (mat mang, app chua chon)
# thi KHONG ghi gi, bot chay nhu cu theo lua chon lan truoc.
# Chi truyen TEN tai khoan, khong co mat khau.
# BAN ASCII, KHONG DAU, KHONG EMOJI.

$Worker  = "https://may-cua-tien.john-honganh-sales.workers.dev"
$VmName  = "May ao 1"                        # <-- SUA: "may ao 1" hoac "may ao bu" (dung ten tren app)
$PollKey = "uYbFf864IVNooZhIw94n8jGCciewXe7Y"           # <-- SUA: copy y het $PollKey trong telegram-vm-start-listener.ps1

$OutFile = "C:\Scripts\runchoice.txt"
$LogFile = "C:\Scripts\fetch-runchoice.log"
$Tries = 12                                   # thu toi 12 lan, moi lan cach 5 giay (cho mang len)

function Write-Log($msg) {
    $time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$time $msg" | Out-File -FilePath $LogFile -Append -Encoding ASCII
}

# Windows cu can bat TLS 1.2 moi goi duoc https.
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

$url = "$Worker/choice?machine=" + [Uri]::EscapeDataString($VmName)
$done = $false

for ($i = 1; $i -le $Tries; $i++) {
    try {
        $r = Invoke-RestMethod -Uri $url -Headers @{ "x-poll-key" = $PollKey } -TimeoutSec 10 -ErrorAction Stop
        if ([string]$r.mode -match '^(10|[1-9])$' -and [string]$r.acc -match '^\S+$') {
            "mode=$($r.mode)" | Out-File -FilePath $OutFile -Encoding ascii -Force
            "acc=$($r.acc)" | Out-File -FilePath $OutFile -Encoding ascii -Append
        if ($r.opts) {
            try {
                $rk = "HKCU:\Software\Buidua"
                if (-not (Test-Path $rk)) { New-Item -Path $rk -Force | Out-Null }
                foreach ($p in $r.opts.PSObject.Properties) {
                    if ($p.Name -notmatch '^(Gp|Zb|Mid|Boss|R11|Fp|Sell|Rz2|Rz10|Char)[A-Za-z0-9]+$') { continue }
                    if ($p.Value -is [string]) { Set-ItemProperty -Path $rk -Name $p.Name -Value $p.Value -Type String }
                    else { Set-ItemProperty -Path $rk -Name $p.Name -Value ([int]$p.Value) -Type DWord }
                    Write-Log ("Ghi cai dat bot: " + $p.Name)
                }
            } catch { Write-Log "LOI ghi cai dat bot: $($_.Exception.Message)" }
        }
            Write-Log "Lan ${i}: lay duoc tu app, che do $($r.mode), tai khoan $($r.acc). Da ghi $OutFile"
            $done = $true
            break
        }
        Write-Log "Lan ${i}: du lieu tra ve khong hop le."
    } catch {
        $code = 0
        try { $code = [int]$_.Exception.Response.StatusCode } catch { }
        if ($code -eq 404) {
            Write-Log "App chua luu lua chon nao cho '$VmName'. Bot chay theo lua chon lan truoc."
            break
        }
        if ($code -eq 401) {
            Write-Log "Sai PollKey (401). Kiem tra lai dong PollKey trong file nay."
            break
        }
        Write-Log "Lan ${i}: loi mang: $($_.Exception.Message)"
    }
    if ($i -lt $Tries) { Start-Sleep -Seconds 5 }
}

if (-not $done) { Write-Log "Khong lay duoc lua chon tu app, giu nguyen runchoice.txt hien co (neu co)." }
exit 0
'@
$files["healthchecks-ping.ps1"] = @'
# healthchecks-ping.ps1 - Ping ngam ve Healthchecks.io (ASCII only, KHONG GUI TIN)
# Moi may co 1 URL ping RIENG, lay tu Healthchecks.io > check cua may do > Copy Ping URL.
# File nay CHI ping ngam, khong gui Telegram. Healthchecks se tu bao Telegram khi mat ping.
# Chay ngam moi 2 phut qua Task Scheduler (task Healthchecks-Heartbeat).

$PingUrl = "PASTE_PING_URL_HERE"

if ($PingUrl -eq "THAY-BANG-URL-RIENG-CUA-MAY-NAY" -or $PingUrl -eq "") {
    $Time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path "$env:TEMP\healthchecks-error.log" -Value "[$Time] Chua dien PingUrl - mo file nay bang Notepad va dan URL ping rieng cua may nay" -ErrorAction SilentlyContinue
    exit 1
}

try {
    Invoke-WebRequest -Uri $PingUrl -TimeoutSec 10 -UseBasicParsing -ErrorAction Stop | Out-Null
    exit 0
} catch {
    $Time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path "$env:TEMP\healthchecks-error.log" -Value "[$Time] Ping FAIL: $($_.Exception.Message)" -ErrorAction SilentlyContinue
    exit 1
}
'@
$files["setup-healthchecks.ps1"] = @'
# setup-healthchecks.ps1 - Doi task heartbeat Telegram sang ping ngam Healthchecks (ASCII only)
# Chay 1 lan tren moi may, bang PowerShell QUYEN ADMIN:
#   powershell -ExecutionPolicy Bypass -File "C:\Scripts\setup-healthchecks.ps1"
# No lam 2 viec:
#   1. Xoa task cu Telegram-PC-Heartbeat (gui tin [RUN] ve Telegram moi 5 phut - bo)
#   2. Tao task moi Healthchecks-Heartbeat (ping ngam ve Healthchecks moi 2 phut, khong gui tin)
# Task Telegram-PC-On va Telegram-PC-Off KHONG DOI - van bao [BAT]/[TAT] nhu cu.

$PingScript = "C:\Scripts\healthchecks-ping.ps1"

$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $IsAdmin) {
    Write-Host "LOI: Phai chay PowerShell bang Run as administrator roi chay lai file nay."
    exit 1
}

if (-not (Test-Path $PingScript)) {
    Write-Host "LOI: Khong thay file: $PingScript"
    Write-Host "Copy file healthchecks-ping.ps1 vao C:\Scripts\ truoc, dien URL ping rieng roi chay lai."
    exit 1
}

# 1. Xoa task heartbeat cu (neu khong co thi bao la da het, khong phai loi)
$OutDel = & schtasks.exe /delete /tn "Telegram-PC-Heartbeat" /f 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "OK: Da xoa Telegram-PC-Heartbeat cu"
} else {
    Write-Host "GHI CHU: Khong thay task Telegram-PC-Heartbeat cu (co the da xoa roi)"
}

# 2. Tao task ping ngam moi 2 phut, chay duoi SYSTEM de khong chop terminal (sua 13:43)
$Cmd = "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$PingScript`""
$Out = & schtasks.exe /create /tn "Healthchecks-Heartbeat" /tr $Cmd /sc minute /mo 2 /ru SYSTEM /rl highest /f 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "OK: Healthchecks-Heartbeat (ping ngam 2 phut/lan)"
} else {
    Write-Host "FAIL: Healthchecks-Heartbeat"
    Write-Host $Out
    exit 1
}

Write-Host ""
Write-Host "Kiem tra:"
schtasks.exe /query /tn "Telegram-PC-On" 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { Write-Host " - Co task Telegram-PC-On (bao BAT)" } else { Write-Host " - THIEU Telegram-PC-On" }
schtasks.exe /query /tn "Telegram-PC-Off" 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { Write-Host " - Co task Telegram-PC-Off (bao TAT)" } else { Write-Host " - THIEU Telegram-PC-Off" }
schtasks.exe /query /tn "Healthchecks-Heartbeat" 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { Write-Host " - Co task Healthchecks-Heartbeat (ping ngam)" } else { Write-Host " - THIEU Healthchecks-Heartbeat" }
schtasks.exe /query /tn "Telegram-PC-Heartbeat" 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { Write-Host " - CANH BAO: Van con task Telegram-PC-Heartbeat cu, can xoa tay" } else { Write-Host " - Da het task Telegram-PC-Heartbeat cu" }
'@
$files["telegram-pc-status-7may.ps1"] = @'
# Telegram PC On/Off - 7 may cua Tien (2026-11-10) - BAN ASCII, KHONG EMOJI
# Ly do: PowerShell 5.1 tren Windows doc file .ps1 theo ANSI neu khong co BOM,
# emoji + tieng Viet co dau se vo thanh ky tu rac va lam vo lenh. Ban nay chi
# dung ky tu ASCII nen chay duoc ngay, khong can doi encoding.
# Cach dung:
#   powershell -ExecutionPolicy Bypass -File "C:\Scripts\telegram-pc-status-7may.ps1" -Status On
#   powershell -ExecutionPolicy Bypass -File "C:\Scripts\telegram-pc-status-7may.ps1" -Status Off
#   powershell -ExecutionPolicy Bypass -File "C:\Scripts\telegram-pc-status-7may.ps1" -Status Heartbeat

param(
    [ValidateSet("On","Off","Heartbeat")]
    [string]$Status = "On"
)

$BotToken = "PASTE_TOKEN_HERE"
$ChatId   = "-5189532438"

# BANG DOI TEN: key = ten Windows that (chay `hostname` tren tung may de lay),
# value = ten goi cua Tien (viet khong dau de tranh loi encoding).
# Dien du 7 dong roi copy cung 1 file nay sang ca 7 may.
# May nao chua dien thi tin nhan se hien ten Windows that, van nhan ra duoc.
$NameMap = @{
    "DESKTOP-XXXX1" = "may chinh nha"
    "DESKTOP-XXXX2" = "may ao 1"
    "DESKTOP-XXXX3" = "may ao bu"
    "DESKTOP-ECF6V94" = "may phu nha"
    "DESKTOP-XXXX5" = "may chinh cty"
    "DESKTOP-XXXX6" = "may phu cty"
    "DESKTOP-XXXX7" = "laptop"
}

$Computer = $env:COMPUTERNAME
if ($NameMap.ContainsKey($Computer)) { $DisplayName = $NameMap[$Computer] }
else { $DisplayName = $Computer }

$User = $env:USERNAME
$Time = Get-Date -Format "dd/MM/yyyy HH:mm:ss"

try {
    $IP = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
        Where-Object { $_.IPAddress -notlike "169.*" -and $_.InterfaceAlias -notlike "*Loopback*" } |
        Select-Object -First 1 -ExpandProperty IPAddress)
} catch { $IP = "?" }

if ($Status -eq "On")        { $Icon = "[BAT]"; $TextStatus = "BAT" }
elseif ($Status -eq "Off")   { $Icon = "[TAT]"; $TextStatus = "TAT" }
else                         { $Icon = "[RUN]"; $TextStatus = "DANG CHAY (heartbeat)" }

$Message = "$Icon $DisplayName $TextStatus`nMay: $Computer`nUser: $User`nIP: $IP`nThoi gian: $Time"

for ($i = 1; $i -le 3; $i++) {
    try {
        Invoke-RestMethod -Uri "https://api.telegram.org/bot$BotToken/sendMessage" `
            -Method Post -Body @{ chat_id = $ChatId; text = $Message } `
            -TimeoutSec 10 -ErrorAction Stop
        Add-Content -Path "$PSScriptRoot\telegram-log.txt" -Value "[$Time] $Status OK - $DisplayName ($Computer)" -ErrorAction SilentlyContinue
        exit 0
    } catch {
        Start-Sleep -Seconds 3
    }
}
Add-Content -Path "$PSScriptRoot\telegram-log.txt" -Value "[$Time] $Status FAIL - $DisplayName ($Computer)" -ErrorAction SilentlyContinue
exit 1
'@

$files["setup-telegram-tasks.ps1"] = @'
# setup-telegram-tasks.ps1 - Tao 2 task bao BAT/TAT qua Telegram bang schtasks.exe (ASCII only)
# Gop tu setup-telegram-tasks-v2.ps1. BO phan Heartbeat vi setup-healthchecks.ps1 da xoa task do.
# Tu chay trong file CAI-may-*.ps1, hoac chay tay bang PowerShell QUYEN ADMIN:
#   powershell -ExecutionPolicy Bypass -File "C:\Scripts\setup-telegram-tasks.ps1"
# No tao:
#   Telegram-PC-On  : luc dang nhap, delay 30s, gui -Status On
#   Telegram-PC-Off : khi co event tat may 1074, gui -Status Off (neu that bai thi dung gpedit)

$ScriptPath = "C:\Scripts\telegram-pc-status-7may.ps1"

$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $IsAdmin) {
    Write-Host "LOI: Phai chay PowerShell bang Run as administrator roi chay lai file nay."
    exit 1
}

if (-not (Test-Path $ScriptPath)) {
    Write-Host "LOI: Khong thay file: $ScriptPath"
    exit 1
}

$Failed = $false

# On: onlogon + delay 30 giay
$CmdOn = "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ScriptPath`" -Status On"
$OutOn = & schtasks.exe /create /tn "Telegram-PC-On" /tr $CmdOn /sc onlogon /delay 0000:30 /rl highest /f 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "OK: Telegram-PC-On"
} else {
    Write-Host "FAIL: Telegram-PC-On"
    Write-Host $OutOn
    $Failed = $true
}

# Off: event System / User32 / 1074
$Query = "*[System[Provider[@Name='User32'] and EventID=1074]]"
$CmdOff = "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ScriptPath`" -Status Off"
$OutOff = & schtasks.exe /create /tn "Telegram-PC-Off" /tr $CmdOff /sc onevent /ec System /mo $Query /rl highest /f 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "OK: Telegram-PC-Off"
} else {
    Write-Host "FAIL: Telegram-PC-Off - dung gpedit thay the:"
    Write-Host "  gpedit.msc > Computer Configuration > Windows Settings > Scripts > Shutdown > Add"
    Write-Host "  Script: powershell.exe"
    Write-Host "  Parameters: -ExecutionPolicy Bypass -File `"$ScriptPath`" -Status Off"
    Write-Host $OutOff
    $Failed = $true
}

Write-Host ""
Write-Host "Kiem tra:"
schtasks.exe /query /tn "Telegram-PC-On" 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { Write-Host " - Co task Telegram-PC-On (bao BAT)" } else { Write-Host " - THIEU Telegram-PC-On" }
schtasks.exe /query /tn "Telegram-PC-Off" 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { Write-Host " - Co task Telegram-PC-Off (bao TAT)" } else { Write-Host " - THIEU Telegram-PC-Off (dung gpedit o tren)" }

if ($Failed) { exit 1 }
'@

foreach ($n in $files.Keys) {
    $s = $files[$n]
    $s = $s.Replace("PASTE_TOKEN_HERE", $token)
    $s = $s.Replace("PASTE_PING_URL_HERE", $pingurl)
    if ($n -eq "telegram-pc-status-7may.ps1") { $s = $s.Replace("DESKTOP-XXXX2", $env:COMPUTERNAME) }
    [IO.File]::WriteAllText("$dst\$n", $s, (New-Object Text.UTF8Encoding($false)))
    Write-Host "OK: da ghi $dst\$n"
}

Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
  Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -match 'telegram-screenshot-listener' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Sleep 2
foreach ($setup in @("setup-screenshot-listener.ps1")) {
    Write-Host "Chay $setup ..."
    powershell -ExecutionPolicy Bypass -File "$dst\$setup"
}

Write-Host "Chay setup-telegram-tasks.ps1 ..."
powershell -ExecutionPolicy Bypass -File "$dst\setup-telegram-tasks.ps1"
if (-not $skipHc) {
    Write-Host "Chay setup-healthchecks.ps1 ..."
    powershell -ExecutionPolicy Bypass -File "$dst\setup-healthchecks.ps1"
}
Write-Host ""
Write-Host "XONG may ao 1 (cai ben trong may ao). Vao web, bam Chup man hinh o 'May ao 1' de thu."
Write-Host ""
Write-Host "BUOC CON LAI (lam 1 lan): de bot lay che do + tai khoan tu app luc may ao khoi dong,"
Write-Host "them dong sau vao DAU script khoi dong bot trong may ao (vd start-bot-automode9.ps1):"
Write-Host "    & `"C:\Scripts\fetch-runchoice.ps1`""
Write-Host "Kiem tra: chay tay fetch-runchoice.ps1 roi xem C:\Scripts\fetch-runchoice.log"
