# Khoi dong bot Lum Tre tu dong khi dang nhap vao may ao.
# Dat TRONG may ao (guest), chay luc user dang nhap (Startup folder).
# Mac dinh mo bot che do 9 bang co /automode9 (tai khoan da luu).
# Neu listener tren May 1 vua copy file lua chon vao
# C:\Scripts\runchoice.txt (2 dong ASCII: mode=<so 1-10> va
# acc=<ten tai khoan>) thi mo bot bang co /automode <mode> <acc>.
# File lua chon chi dung 1 LAN: doc xong la XOA ngay, de lan mo may
# sau khong dung lai lua chon cu. Khong co file (hoac file sai dinh
# dang) thi mo nhu cu bang /automode9.
# MOI: truoc khi doc file lua chon, script goi C:\Scripts\fetch-runchoice.ps1 de HOI APP
# (Worker) xem dang chon che do + tai khoan nao cho may ao nay. Lay duoc thi file do
# ghi san runchoice.txt va script dung nhu tren. Khong lay duoc (mat mang, app chua
# chon) thi van cho listener May 1 copy file vao nhu cu, het gio moi chay /automode9.
# BAN ASCII, KHONG DAU, KHONG EMOJI.

$BotExe = "C:\Users\Administrator\Desktop\CHIKA\Treomid\All-in-one.exe"
$DelaySec = 30
$LogFile = "C:\Scripts\bot-automode9.log"
$RunChoiceFile = "C:\Scripts\runchoice.txt"
$ChoiceWaitSec = 60
$ChoicePollSec = 5
$FetchScript = "C:\Scripts\fetch-runchoice.ps1"

function Write-Log($msg) {
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] $msg"
    try { Add-Content -Path $LogFile -Value $line -Encoding ascii } catch { }
    Write-Host $line
}

# Bot da chay roi thi thoat lang, khong mo ban thu 2.
if (Get-Process -Name "All-in-one" -ErrorAction SilentlyContinue) {
    Write-Log "Bot da chay roi, thoat."
    exit 0
}

Write-Log "Doi $DelaySec giay cho desktop len han roi moi mo bot..."
Start-Sleep -Seconds $DelaySec

if (Get-Process -Name "All-in-one" -ErrorAction SilentlyContinue) {
    Write-Log "Bot da chay roi (mo trong luc doi), thoat."
    exit 0
}
if (-not (Test-Path $BotExe)) {
    Write-Log "LOI: Khong tim thay file bot: $BotExe. Sua bien `$BotExe o dau file nay."
    exit 1
}

# Hoi app (Worker) xem dang chon che do + tai khoan nao. Lay duoc thi fetch-runchoice
# ghi san C:\Scripts\runchoice.txt, vong cho ben duoi thay file la chay ngay.
if (Test-Path $FetchScript) {
    Write-Log "Hoi app xem chon che do + tai khoan nao..."
    try { & $FetchScript } catch { Write-Log "LOI goi fetch-runchoice: $($_.Exception.Message)" }
} else {
    Write-Log "Khong thay $FetchScript, bo qua buoc hoi app."
}

# Doi file lua chon (fetch-runchoice ghi, hoac listener tren May 1 copy vao).
# Poll moi 5 giay, toi da 60 giay.
$mode = ""
$acc = ""
$waited = 0
while ($waited -le $ChoiceWaitSec) {
    if (Test-Path $RunChoiceFile) { break }
    Start-Sleep -Seconds $ChoicePollSec
    $waited += $ChoicePollSec
}
if (Test-Path $RunChoiceFile) {
    $lines = Get-Content $RunChoiceFile -ErrorAction SilentlyContinue
    # Xoa ngay sau khi doc, file chi dung 1 lan.
    try { Remove-Item $RunChoiceFile -Force -ErrorAction Stop } catch {
        Write-Log "CANH BAO: Doc duoc file lua chon nhung khong xoa duoc $RunChoiceFile : $($_.Exception.Message)"
    }
    $readMode = ""
    $readAcc = ""
    foreach ($ln in $lines) {
        $t = $ln.Trim()
        if ($t -match '^mode=(10|[1-9])$') { $readMode = $Matches[1] }
        if ($t -match '^acc=(\S+)$') { $readAcc = $Matches[1] }
    }
    if ($readMode -ne "" -and $readAcc -ne "") {
        $mode = $readMode
        $acc = $readAcc
        Write-Log "Nhan duoc lua chon tu app: che do $mode, tai khoan $acc."
    } else {
        Write-Log "File lua chon sai dinh dang (can 2 dong mode=<so 1-10> va acc=<1 tu>), bo qua, chay mac dinh che do 9."
    }
} else {
    Write-Log "Khong co file lua chon sau $ChoiceWaitSec giay, chay mac dinh che do 9."
}

if ($mode -ne "" -and $acc -ne "") {
    $botArgs = "/automode $mode $acc"
} else {
    $botArgs = "/automode9"
}

Write-Log "Mo bot: $BotExe $botArgs"
Start-Process -FilePath $BotExe -ArgumentList $botArgs -WindowStyle Normal
Start-Sleep -Seconds 5
if (Get-Process -Name "All-in-one" -ErrorAction SilentlyContinue) {
    Write-Log "OK: Bot da mo."
} else {
    Write-Log "CANH BAO: 5 giay sau khi mo van khong thay tien trinh All-in-one. Xem co hop thoai UAC (xin quyen Admin) dang doi bam hay khong."
}