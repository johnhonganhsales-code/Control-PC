# CAI DAT 1 FILE - MAY CHINH NHA (host, co 2 may ao)
# Cach chay: mo PowerShell bang quyen Administrator (chuot phai > Run as administrator), dan:
#   powershell -ExecutionPolicy Bypass -File "<duong dan toi file nay>"
# File nay chua SAN toan bo script cua may nay, khong can file nao khac.
# Trong file co POLL_KEY that: KHONG dua len mang, KHONG gui cho nguoi la.
$ErrorActionPreference = "Stop"
$dst = "C:\Scripts"
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) { Write-Host "LOI: hay mo PowerShell bang Run as administrator roi chay lai."; exit 1 }
New-Item -ItemType Directory -Force $dst | Out-Null
try { Add-MpPreference -ExclusionPath $dst; Write-Host "OK: da them ngoai le antivirus cho $dst" }
catch { Write-Host "CANH BAO: khong them duoc ngoai le. Neu dung antivirus khac, tu them $dst vao Exclusions." }

$token = (Read-Host "Dan BOT TOKEN (dang 123456789:ABC...)").Trim().Trim('"')
if ($token -notmatch '^\d+:[\w-]+$') { Write-Host "LOI: token sai (phai co dau hai cham giua). Chay lai."; exit 1 }
function Esc($v) { $v.Replace('`','``').Replace('"','`"').Replace('$','`$') }
$botexe = (Read-Host "Duong dan file bot All-in-one.exe tren may nay (vd C:\Bot\All-in-one.exe)").Trim().Trim('"')
if (-not (Test-Path $botexe)) { Write-Host "CANH BAO: khong thay file nay tren may. Van tiep tuc, nhung RUN se loi cho toi khi sua BotExe trong C:\Scripts\chay-bot.ps1." }
$gu = Read-Host "Tai khoan Windows TRONG may ao (khong bat buoc, Enter de bo qua: may ao tu lay che do tu app luc khoi dong)"
$gp = ""
if ($gu -ne "") { $gp = Read-Host "Mat khau Windows TRONG may ao" }
$wat = Read-Host "Cai luon watcher tu mo lai may ao v5? (y/n)"
$pingurl = (Read-Host "Dan URL ping RIENG cua may nay (Healthchecks.io > check cua may nay > Copy Ping URL). Enter de bo qua").Trim().Trim('"')
$skipHc = $false
if ($pingurl -eq "") { $skipHc = $true; Write-Host "CANH BAO: bo qua Healthchecks cho may nay (sau nay chay lai file cai dat de them)." }
elseif ($pingurl -notmatch '^https://hc-ping\.com/\S+$') { Write-Host "LOI: URL ping phai dang https://hc-ping.com/... Chay lai."; exit 1 }

$files = [ordered]@{}
$files["telegram-screenshot-listener.ps1"] = @'
# Nghe lenh chup man hinh + tat may qua Telegram/Worker - CHAY TREN MOI MAY CAN CHUP
# Dat file nay vao C:\Scripts\telegram-screenshot-listener.ps1 tren TUNG may.
# Cach dung: trong nhom MY PC hoac trong app "May cua Tien", gui:
#   /chupmanhinh <ten may>
#   /tatmay <ten may>      (shutdown may, sau 10 giay)
#   /khoidonglai <ten may> (restart may, sau 10 giay)
#   /batmay <ten may>      (Wake-on-LAN: chi may $WolSender gui goi bat)
# Vi du: /chupmanhinh May chinh cty
# Chi may co $MyName trung ten do moi chup va gui anh ve nhom.
# BAN ASCII, KHONG DAU, KHONG EMOJI.
# QUAN TRONG: script nay PHAI chay duoi user dang dang nhap (qua Startup),
# KHONG chay duoi SYSTEM - SYSTEM khong co desktop nen chup ra anh den.

$BotToken = "PASTE_TOKEN_HERE"      # <-- copy token y het trong telegram-pc-status-7may.ps1
$ChatId   = "-5189532438"           # <-- nhom MY PC
$AllowedUserId = 1444024297         # <-- chi nhan lenh tu Tien
$QueueUrl = "https://may-cua-tien.john-honganh-sales.workers.dev"   # <-- URL Worker
$PollKey  = "uYbFf864IVNooZhIw94n8jGCciewXe7Y"                    # <-- giong secret POLL_KEY
$MyName = "May chinh nha"        # <-- SUA: ten may nay, giong het ten check
                                    # tren Healthchecks, vi du: May chinh cty
                                    # So sanh khong phan biet hoa/thuong.

$ScriptDir = "C:\Scripts"
$LogFile = "$ScriptDir\screenshot-telegram.log"
$OffsetFile = "$ScriptDir\screenshot-offset-queue.txt"

# Bat may tu xa bang Wake-on-LAN. Chi may co ten $WolSender (may luon bat) moi gui goi bat.
# Cac may khac cung chay file nay nhung bo qua lenh /batmay.
$WolSender = "may phu nha"
$WolTargets = @{ "may chinh nha" = "EC-D6-8A-DE-87-7A" }   # MAC may chinh nha (lay tu wol-telegram-listener.ps1 dang chay duoc)
$WolBroadcast = "192.168.68.255"                            # broadcast mang LAN nha (IP 192.168.68.x)
$ShotFile = "$env:TEMP\screenshot.jpg"

function Write-Log($msg) {
    $time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$time $msg" | Out-File -FilePath $LogFile -Append -Encoding UTF8
}

# Chong chay trung 2 tien trinh (vu WoL v3 da bi trung 2 tin).
# Mutex giu suot luc script chay, tien trinh thu 2 thay da co thi thoat ngay.
$Mutex = New-Object System.Threading.Mutex($false, "Global\TelegramScreenshotListener")
if (-not $Mutex.WaitOne(0)) { exit }

function Invoke-Tg($Method, $BodyObj) {
    $json = $BodyObj | ConvertTo-Json -Depth 5 -Compress
    try {
        $r = Invoke-RestMethod -Uri "https://api.telegram.org/bot$BotToken/$Method" `
            -Method Post -ContentType "application/json" -Body $json `
            -TimeoutSec 10 -ErrorAction Stop
        return $r
    } catch {
        $detail = $_.ErrorDetails.Message
        if (-not $detail) { $detail = $_.Exception.Message }
        Write-Log "$Method LOI: $detail"
        return $null
    }
}

function Send-Telegram($Text) {
    $r = Invoke-Tg "sendMessage" @{ chat_id = $ChatId; text = $Text }
    return ($null -ne $r)
}

function Take-Screenshot() {
    try {
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        $bounds = [System.Windows.Forms.SystemInformation]::VirtualScreen
        $bmp = New-Object System.Drawing.Bitmap($bounds.Width, $bounds.Height)
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
        $g.Dispose()
        # Luu JPEG chat luong 70 cho nhe (vai tram KB).
        $codec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() |
            Where-Object { $_.MimeType -eq "image/jpeg" }
        $params = New-Object System.Drawing.Imaging.EncoderParameters(1)
        $params.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter(
            [System.Drawing.Imaging.Encoder]::Quality, [long]70)
        $bmp.Save($ShotFile, $codec, $params)
        $bmp.Dispose()
        if (Test-Path $ShotFile) { return $ShotFile }
        Write-Log "Chup xong nhung khong thay file $ShotFile"
        return $null
    } catch {
        Write-Log "Chup man hinh LOI: $($_.Exception.Message)"
        return $null
    }
}

function Send-Photo($FilePath, $Caption) {
    # Dung curl.exe co san tren Windows 10/11 de gui multipart/form-data.
    # PowerShell 5.1 khong co Invoke-RestMethod -Form nen khong dung cach do.
    $curl = "$env:SystemRoot\System32\curl.exe"
    if (-not (Test-Path $curl)) { $curl = "curl.exe" }
    try {
        $out = & $curl -s --max-time 30 `
            -F "chat_id=$ChatId" `
            -F "caption=$Caption" `
            -F "photo=@$FilePath" `
            "https://api.telegram.org/bot$BotToken/sendPhoto" 2>&1
        if ($out -match '"ok":true') { return $true }
        Write-Log "Gui anh LOI, Telegram tra: $out"
        return $false
    } catch {
        Write-Log "Gui anh LOI: $($_.Exception.Message)"
        return $false
    }
}

function Send-Wol($Mac) {
    $hex = ($Mac -replace '[^0-9A-Fa-f]', '')
    if ($hex.Length -ne 12) { return $false }
    $macBytes = for ($i = 0; $i -lt 12; $i += 2) { [Convert]::ToByte($hex.Substring($i, 2), 16) }
    $packet = [byte[]](@(0xFF) * 6 + $macBytes * 16)
    $udp = New-Object System.Net.Sockets.UdpClient
    try {
        $udp.EnableBroadcast = $true
        # Gui 3 dot cach nhau 4 giay (giong cach wol-telegram-listener.ps1 gui nhieu lan cho chac).
        for ($n = 1; $n -le 3; $n++) {
            foreach ($ip in @($WolBroadcast, "255.255.255.255")) {
                foreach ($port in @(9, 7)) { [void]$udp.Send($packet, $packet.Length, $ip, $port) }
            }
            if ($n -lt 3) { Start-Sleep -Seconds 4 }
        }
    } finally { $udp.Close() }
    return $true
}

Write-Log "Screenshot listener khoi dong, may=$MyName"

function Upload-Shot($path) {
    try {
        $m = [uri]::EscapeDataString($MyName.ToLower())
        Invoke-RestMethod -Uri "$QueueUrl/shot?machine=$m" -Method Post -Headers @{ "X-Poll-Key" = $PollKey } -InFile $path -ContentType "image/jpeg" -TimeoutSec 60 | Out-Null
        Write-Log "Da gui anh len web"
    } catch { Write-Log "Gui anh len web LOI: $($_.Exception.Message)" }
}
$Offset = 0
if (Test-Path $OffsetFile) {
    $saved = Get-Content $OffsetFile -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($saved -match '^\d+$') { $Offset = [int64]$saved }
}

# Xu ly 1 lenh (dung chung cho WebSocket va HTTP poll). Bo qua lenh da xu ly (update_id < Offset).
function Process-Update($upd) {
    if ([int64]$upd.update_id -lt $script:Offset) { return }
            $script:Offset = [int64]$upd.update_id + 1
            $script:Offset | Out-File -FilePath $OffsetFile -Encoding ascii -Force

            if (-not $upd.message -or -not $upd.message.text) { return }
            $txt = $upd.message.text.Trim()
            $who = $upd.message.from.id
            $chat = $upd.message.chat.id

            # Chi nhan lenh trong nhom MY PC, tu dung Tien.
            if ([string]$chat -ne [string]$ChatId) { return }
            if ([string]$who -ne [string]$AllowedUserId) { return }

            # /batmay <ten may>: chi may $WolSender gui goi Wake-on-LAN. Bo qua lenh cu hon 2 phut.
            if ($txt -match '^/batmay(@\w+)?\s+(.+)$') {
                $wTarget = $Matches[2].Trim().ToLower()
                if ($MyName.ToLower() -ne $WolSender.ToLower()) { return }
                $nowMs = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
                if (($nowMs - [int64]$upd.update_id) -gt 120000) {
                    Write-Log "Bo qua lenh batmay cu (qua 2 phut)"
                    return
                }
                if (-not $WolTargets.ContainsKey($wTarget)) {
                    Write-Log "batmay: '$wTarget' chua co trong WolTargets"
                    Send-Telegram "May $MyName chua biet dia chi MAC cua '$wTarget'. Dien vao WolTargets trong telegram-screenshot-listener.ps1."
                    return
                }
                if (Send-Wol $WolTargets[$wTarget]) {
                    Write-Log "batmay: da gui goi Wake-on-LAN toi $wTarget"
                    Send-Telegram "May $MyName da gui lenh bat toi $wTarget. Doi khoang 30-60 giay."
                } else {
                    Write-Log "batmay: dia chi MAC cua $wTarget khong hop le"
                    Send-Telegram "Dia chi MAC cua $wTarget trong WolTargets khong hop le (can dang AA-BB-CC-DD-EE-FF)."
                }
                return
            }

            # Lenh la /chupmanhinh, /tatmay hoac /khoidonglai <ten may>, co the kem @ControlPCofTienbot.
            if ($txt -notmatch '^/(chupmanhinh|tatmay|khoidonglai)(@\w+)?(\s+(.+))?$') { return }
            $cmd = $Matches[1]
            $target = ""
            if ($Matches[4]) { $target = $Matches[4].Trim() }
            Write-Log "Nhan lenh $cmd target='$target' tu user=$who"
            if ($target -eq "") { return }
            if ($target.ToLower() -ne $MyName.ToLower()) { return }

            # TAT MAY: shutdown sau 10 giay. Bo qua lenh cu hon 2 phut de tranh
            # tat nham khi may vua bat lai (update_id chinh la moc thoi gian ms).
            if ($cmd -eq "tatmay") {
                $nowMs = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
                if (($nowMs - [int64]$upd.update_id) -gt 120000) {
                    Write-Log "Bo qua lenh tatmay cu (qua 2 phut)"
                    return
                }
                Write-Log "Thuc hien TAT MAY $MyName"
                Send-Telegram "May $MyName se tat sau 10 giay."
                & "$env:SystemRoot\System32\shutdown.exe" /s /f /t 10 /c "Tat may tu app May cua Tien"
                return
            }

            # KHOI DONG LAI: restart sau 10 giay. Cung bo qua lenh cu hon 2 phut.
            if ($cmd -eq "khoidonglai") {
                $nowMs = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
                if (($nowMs - [int64]$upd.update_id) -gt 120000) {
                    Write-Log "Bo qua lenh khoidonglai cu (qua 2 phut)"
                    return
                }
                Write-Log "Thuc hien KHOI DONG LAI $MyName"
                Send-Telegram "May $MyName se khoi dong lai sau 10 giay."
                & "$env:SystemRoot\System32\shutdown.exe" /r /f /t 10 /c "Khoi dong lai tu app May cua Tien"
                return
            }

            $file = Take-Screenshot
            if ($file) {
                $time = Get-Date -Format "HH:mm:ss dd-MM-yyyy"
                Upload-Shot $file
                $ok = Send-Photo $file "Man hinh $MyName - $time"
                if ($ok) { Write-Log "Da gui anh man hinh $MyName" }
            } else {
                Send-Telegram "May $MyName chup man hinh LOI, xem log C:\Scripts\screenshot-telegram.log"
            }
}

# --- WebSocket toi Worker (Durable Object): nhan lenh tuc thi. HTTP /poll chi con la du phong. ---
$script:Ws = $null; $script:WsTask = $null; $script:WsText = ""; $script:WsFails = 0
$script:WsBuf = New-Object byte[] 16384
$script:WsLastPing = Get-Date; $script:WsLastTry = [DateTime]::MinValue
$WsUrl = ($QueueUrl -replace '^http', 'ws').TrimEnd('/') + "/ws?machine=" + [uri]::EscapeDataString($MyName.ToLower())

function Ws-Close {
    if ($script:Ws) { try { $script:Ws.Dispose() } catch {} }
    $script:Ws = $null; $script:WsTask = $null; $script:WsText = ""
}

function Ws-Connect {
    $script:WsLastTry = Get-Date
    try {
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
        $c = New-Object System.Net.WebSockets.ClientWebSocket
        $c.Options.SetRequestHeader("X-Poll-Key", $PollKey)
        if (-not $c.ConnectAsync([Uri]$WsUrl, [Threading.CancellationToken]::None).Wait(10000)) {
            $c.Dispose(); $script:WsFails++
            if ($script:WsFails -le 2) { Write-Log "WS: ket noi qua han, dung HTTP poll du phong" }
            return
        }
        $script:Ws = $c
        $script:WsFails = 0
        $script:WsLastPing = Get-Date
        $script:WsTask = $c.ReceiveAsync([ArraySegment[byte]]::new($script:WsBuf), [Threading.CancellationToken]::None)
        Write-Log "WS: da ket noi"
    } catch {
        $script:WsFails++
        if ($script:WsFails -le 2) { Write-Log ("WS: khong ket noi duoc: " + $_.Exception.Message + " (dung HTTP poll du phong)") }
        Ws-Close
    }
}

# Moi lan goi: toi da ~1 giay cho tin nhan WebSocket; xu ly lenh neu co; gui ping giu ket noi.
function Ws-Tick {
    if (-not $script:Ws) {
        $wait = [Math]::Min(300, 20 * [Math]::Pow(2, [Math]::Min($script:WsFails, 4)))
        if (((Get-Date) - $script:WsLastTry).TotalSeconds -ge $wait) { Ws-Connect }
        if (-not $script:Ws) { Start-Sleep -Seconds 1; return }
    }
    try {
        if ($script:Ws.State -ne [System.Net.WebSockets.WebSocketState]::Open) { throw "WS khong con mo" }
        if ($script:WsTask.Wait(1000)) {
            $r = $script:WsTask.Result
            if ($r.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) { throw "WS bi dong" }
            $script:WsText += [Text.Encoding]::UTF8.GetString($script:WsBuf, 0, $r.Count)
            $msg = $null
            if ($r.EndOfMessage) { $msg = $script:WsText; $script:WsText = "" }
            $script:WsTask = $script:Ws.ReceiveAsync([ArraySegment[byte]]::new($script:WsBuf), [Threading.CancellationToken]::None)
            if ($msg -and $msg -ne "pong") {
                try { Process-Update ($msg | ConvertFrom-Json) }
                catch { Write-Log ("Xu ly lenh WS LOI: " + $_.Exception.Message) }
            }
        }
        if (((Get-Date) - $script:WsLastPing).TotalSeconds -ge 25) {
            $script:WsLastPing = Get-Date
            [void]$script:Ws.SendAsync([ArraySegment[byte]]::new([Text.Encoding]::UTF8.GetBytes("ping")), [System.Net.WebSockets.WebSocketMessageType]::Text, $true, [Threading.CancellationToken]::None).Wait(5000)
        }
    } catch {
        Write-Log ("WS: mat ket noi (" + $_.Exception.Message + "), dung HTTP poll du phong")
        Ws-Close
    }
}

# Vong chinh: WebSocket la duong chinh. Khi WS dang noi, HTTP poll 60 giay/lan de du phong; khi WS mat, 15 giay/lan nhu cu.
$LastPoll = [DateTime]::MinValue
while ($true) {
    Ws-Tick
    $gap = 15; if ($script:Ws) { $gap = 60 }
    if (((Get-Date) - $LastPoll).TotalSeconds -ge $gap) {
        $LastPoll = Get-Date
        try {
            # Lay lenh tu Worker (hang doi), khong dung getUpdates cua Telegram nua.
            $resp = Invoke-RestMethod -Uri "$QueueUrl/poll?since=$Offset" -Headers @{ "X-Poll-Key" = $PollKey } -TimeoutSec 15 -ErrorAction Stop
            foreach ($upd in $resp.result) { Process-Update $upd }
        } catch {
            Write-Log "Poll LOI: $($_.Exception.Message)"
            Start-Sleep -Seconds 5
        }
    }
}
'@
$files["chay-bot-listener.ps1"] = @'
# Nhan lenh /chaybot <ten may> <che do> <tai khoan> tu Worker, roi mo bot tren may nay.
# BAN ASCII, KHONG DAU.
$BotToken = "PASTE_TOKEN_HERE"
$ChatId   = "-5189532438"
$MyName   = "May chinh nha"
$QueueUrl = "https://may-cua-tien.john-honganh-sales.workers.dev"
$PollKey  = "uYbFf864IVNooZhIw94n8jGCciewXe7Y"
$LogFile    = "C:\Scripts\chay-bot-listener.log"
$OffsetFile = "C:\Scripts\chay-bot-offset.txt"
$ChoiceFile = "C:\Scripts\runchoice-run.txt"
$TaskName   = "ChayBotTheoLenh"

function Write-Log($m) { try { Add-Content $LogFile ("[" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + "] " + $m) -Encoding ascii } catch { } }
function Send-Telegram($t) {
    try { Invoke-RestMethod -Uri "https://api.telegram.org/bot$BotToken/sendMessage" -Method Post -Body @{ chat_id = $ChatId; text = $t } -TimeoutSec 15 | Out-Null }
    catch { Write-Log "Gui Telegram LOI: $($_.Exception.Message)" }
}

$created = $false
$mutex = New-Object System.Threading.Mutex($true, "Global\ChayBotListener", [ref]$created)
if (-not $created) { exit 0 }
if ($BotToken -like "PASTE*" -or $MyName -like "THAY*") { Write-Log "LOI: chua dien token hoac ten may"; exit 1 }

$Offset = [int64]0
if (Test-Path $OffsetFile) { try { $Offset = [int64](Get-Content $OffsetFile -Raw).Trim() } catch { $Offset = [int64]0 } }
Write-Log "Listener chay bot khoi dong, may=$MyName"

while ($true) {
    try {
        $resp = Invoke-RestMethod -Uri "$QueueUrl/poll?since=$Offset" -Headers @{ "X-Poll-Key" = $PollKey } -TimeoutSec 15 -ErrorAction Stop
        foreach ($u in $resp.result) {
            $Offset = [int64]$u.update_id + 1
            Set-Content $OffsetFile $Offset -Encoding ascii
            $txt = [string]$u.message.text
            if ($txt -notmatch '^/chaybot\s+(.+?)\s+(10|[1-9])\s+(\S+)(?:\s+(\S+))?\s*$') { continue }
            $target = $Matches[1].Trim().ToLower(); $mode = $Matches[2]; $acc = $Matches[3]; $opts = $Matches[4]
            if ($target -ne $MyName.ToLower()) { continue }
            Write-Log "Nhan lenh RUN: che do $mode, tai khoan $acc"
            if (Get-Process -Name "All-in-one" -ErrorAction SilentlyContinue) {
                Send-Telegram "$MyName`: bot dang chay roi nen khong mo them. Hay dung bot roi bam RUN lai."
                continue
            }
            $lines = @("mode=$mode", "acc=$acc"); if ($opts) { $lines += "opts=$opts" }; $lines | Set-Content $ChoiceFile -Encoding ascii
            schtasks /run /tn $TaskName | Out-Null
            if ($LASTEXITCODE -eq 0) { Send-Telegram "$MyName`: da gui lenh RUN (che do $mode, tai khoan $acc)." }
            else { Send-Telegram "$MyName`: LOI khong chay duoc task $TaskName. Chay lai setup-chay-bot.ps1 bang quyen admin." }
        }
    } catch { Write-Log "Poll LOI: $($_.Exception.Message)" }
    Start-Sleep -Seconds 15
}
'@
$files["chay-bot.ps1"] = @'
# Chay boi Task Scheduler (quyen cao nhat, khong bi UAC chan). Doc lua chon roi mo bot.
# BAN ASCII, KHONG DAU.
$BotExe = "PASTE_BOT_EXE_HERE"
$ChoiceFile = "C:\Scripts\runchoice-run.txt"
$LogFile = "C:\Scripts\chay-bot.log"
function Write-Log($m) { try { Add-Content $LogFile ("[" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + "] " + $m) -Encoding ascii } catch { } }

if (Get-Process -Name "All-in-one" -ErrorAction SilentlyContinue) { Write-Log "Bot da chay roi, thoat."; exit 0 }
if (-not (Test-Path $BotExe)) { Write-Log "LOI: khong thay file bot: $BotExe"; exit 1 }
$mode = ""; $acc = ""; $optsB64 = ""
if (Test-Path $ChoiceFile) {
    $lines = Get-Content $ChoiceFile -ErrorAction SilentlyContinue
    Remove-Item $ChoiceFile -Force -ErrorAction SilentlyContinue
    foreach ($ln in $lines) {
        $t = $ln.Trim()
        if ($t -match '^mode=(10|[1-9])$') { $mode = $Matches[1] }
        if ($t -match '^acc=(\S+)$') { $acc = $Matches[1] }
        if ($t -match '^opts=(\S+)$') { $optsB64 = $Matches[1] }
    }
}
if ($mode -eq "" -or $acc -eq "") { Write-Log "Khong co lua chon hop le, khong mo bot."; exit 1 }
# Cai dat phu cua che do: ghi vao registry cua bot (HKCU\Software\Buidua) TRUOC khi mo bot; bot nap lai luc khoi dong.
if ($optsB64 -ne "") {
    try {
        $o = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($optsB64)) | ConvertFrom-Json
        $rk = "HKCU:\Software\Buidua"
        if (-not (Test-Path $rk)) { New-Item -Path $rk -Force | Out-Null }
        foreach ($p in $o.PSObject.Properties) {
            if ($p.Name -notmatch '^(Gp|Zb|Mid|Boss|R11|Fp|Sell|Rz2|Rz10|Char)[A-Za-z0-9]+$') { continue }
            if ($p.Value -is [string]) { Set-ItemProperty -Path $rk -Name $p.Name -Value $p.Value -Type String }
            else { Set-ItemProperty -Path $rk -Name $p.Name -Value ([int]$p.Value) -Type DWord }
            Write-Log ("Ghi cai dat bot: " + $p.Name)
        }
    } catch { Write-Log ("LOI ghi cai dat bot: " + $_.Exception.Message) }
}
Write-Log "Mo bot: $BotExe /automode $mode $acc"
Start-Process -FilePath $BotExe -ArgumentList "/automode $mode $acc" -WorkingDirectory (Split-Path $BotExe) -WindowStyle Normal
Start-Sleep -Seconds 5
if (Get-Process -Name "All-in-one" -ErrorAction SilentlyContinue) { Write-Log "OK: bot da mo." } else { Write-Log "CANH BAO: sau 5 giay chua thay tien trinh All-in-one." }
'@
$files["telegram-vm-start-listener.ps1"] = @'
# Nghe lenh mo may ao qua Telegram - CHAY TREN MAY 1 (HOST, DESKTOP-GLMQ72B)
# Dat file nay vao C:\Scripts\telegram-vm-start-listener.ps1 tren MAY 1.
# Cach dung: trong nhom MY PC hoac trong app "May cua Tien" (v1.4+), gui:
#   /movat may ao 1      -> mo may ao May 1 (bot chay mac dinh che do 9)
#   /movat may ao bu     -> mo may ao TREO BU (bot chay mac dinh che do 9)
#   /movat may ao bu 9 valenline1998
#                        -> mo may ao TREO BU, bot trong may ao se chay
#                           che do 9 voi tai khoan valenline1998
#   /tamngungvm may ao bu -> tam ngung RIENG may ao bu (tao file
#                           vm-autorestart-may-ao-bu.pause). May ao 1
#                           van theo doi binh thuong.
#   /tieptucvm may ao bu  -> tiep tuc RIENG may ao bu (xoa file pause
#                           rieng cua no). Watcher se mo lai may do
#                           sau 60 giay neu no dang tat (listener tu hen gio).
#   Len tam ngung / tiep tuc BAT BUOC kem ten may ao (may ao 1 / may ao bu).
#   Gui lenh tran khong kem ten (/tamngungvm, /tieptucvm) thi listener
#   chi tra loi huong dan dung, KHONG lam gi. Ten may sai cung chi tra
#   loi huong dan, KHONG lam gi. Khong con lenh nao anh huong ca 2 may
#   cung luc.
# Chi 2 may ao tren moi chap nhan lenh nay. May khac khong co nut nay trong app.
# Tam ngung chi chan watcher TU MO LAI may ao da tat; may nao dang chay van
# chay cho toi khi Tien tat tay trong Workstation. Bam Tiep tuc thi chi
# may ao do tu mo lai sau 60 giay.
# Cung 1 tien trinh nay nghe ca 3 lenh (/movat, /tamngungvm, /tieptucvm).
# TUYET DOI KHONG chay them tien trinh poll getUpdates thu 2 tren cung bot
# token (2 poller se cuop update cua nhau).
# BAN ASCII, KHONG DAU, KHONG EMOJI.
# QUAN TRONG: luc bam nut, cua so VMware Workstation tren May 1 PHAI DANG DONG
# HAN. Neu GUI dang mo thi vmrun se bao "The file is already in use" va mo
# khong duoc (GUI giu khoa file .vmx). Listener se bao ro loi nay ve nhom.
# Listener nay chay duoi user dang dang nhap (qua Startup), KHONG chay
# duoi SYSTEM. Khong sua watcher tu dong mo lai (watch-vmware-vm.ps1).
# CHE DO + TAI KHOAN (moi tu app v1.4): khi lenh /movat kem che do va tai
# khoan, listener ghi file lua chon tren host roi copy vao trong khach
# (C:\Scripts\runchoice.txt) bang vmrun CopyFileFromHostToGuest. Can
# VMware Tools trong khach dang chay moi copy duoc, va can dien dung
# $GuestUser / $GuestPass (tai khoan Windows trong may ao) o dau file nay.
# Copy khong duoc thi may ao VAN MO LENH, chi la bot se chay mac dinh
# che do 9 + tai khoan da luu (co /automode9). File lua chon tren host:
#   C:\Scripts\runchoice-may-ao-1.txt  (may ao 1)
#   C:\Scripts\runchoice-may-ao-bu.txt (may ao bu)
# Noi dung file (ASCII, 2 dong): mode=<so 1-10> va acc=<ten tai khoan>.
# Chi co TEN tai khoan, KHONG co mat khau. Mat khau bot lay trong
# accounts.ini nhu cu.

$BotToken = "PASTE_TOKEN_HERE"      # <-- copy token y het trong telegram-pc-status-7may.ps1
$ChatId   = "-5189532438"           # <-- nhom MY PC
$AllowedUserId = 1444024297         # <-- chi nhan lenh tu Tien
$QueueUrl = "https://may-cua-tien.john-honganh-sales.workers.dev"   # <-- URL Worker
$PollKey  = "uYbFf864IVNooZhIw94n8jGCciewXe7Y"                    # <-- giong secret POLL_KEY

# Tai khoan Windows TRONG may ao, dung de copy file lua chon vao khach.
# Dien dung user/pass dang nhap Windows cua may ao (ca 2 may ao dung
# chung 1 cap nay neu giong nhau; khac nhau thi phai sua lai code).
$GuestUser = "PASTE_GUEST_USER_HERE"
$GuestPass = "PASTE_GUEST_PASS_HERE"

$ScriptDir = "C:\Scripts"
$LogFile = "$ScriptDir\vm-start-telegram.log"
$OffsetFile = "$ScriptDir\vm-start-offset-queue.txt"

# Ten viet tat (slug) theo ten check: khoang trang -> gach ngang.
# Vd: "may ao 1" -> may-ao-1, "may ao bu" -> may-ao-bu. Dung chung
# cho ca file lua chon runchoice va file tam ngung rieng.
function Get-Slug($CheckName) {
    return $CheckName.ToLower() -replace '\s+', '-'
}

# File tam ngung RIENG cua 1 may ao (watcher v5): "may ao 1" ->
# C:\Scripts\vm-autorestart-may-ao-1.pause ; "may ao bu" ->
# C:\Scripts\vm-autorestart-may-ao-bu.pause. Khong con file chung.
function Get-PauseFilePath($CheckName) {
    return "$ScriptDir\vm-autorestart-$(Get-Slug $CheckName).pause"
}
# Duong dan file lua chon TRONG khach (script start-bot-automode9.ps1
# trong may ao se doc file nay).
$RunChoiceGuestPath = "C:\Scripts\runchoice.txt"

# 2 may ao tren May 1. Key = ten check tren Healthchecks / ten trong app
# (so sanh khong phan biet hoa/thuong). Path = duong dan file .vmx that.
$Vms = @{
    "may ao 1"  = @{ Path = "D:\MAY 1\May 1.vmx"; Name = "May 1" }
    "may ao bu" = @{ Path = "D:\win 10 CF 19H2 GHOST RELEASED\win 10.vmx"; Name = "TREO BU" }
}

$VmrunPaths = @(
    "C:\Program Files (x86)\VMware\VMware Workstation\vmrun.exe",
    "C:\Program Files\VMware\VMware Workstation\vmrun.exe"
)
$StartWaitSec = 30
$CopyRetrySec = 15
$CopyTimeoutSec = 180
# Sau khi bam Tiep tuc, doi bay nhieu giay roi neu may ao dang tat thi listener tu mo lai.
$ResumeDelaySec = 60
$PendingResume = @{}

function Write-Log($msg) {
    $time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$time $msg" | Out-File -FilePath $LogFile -Append -Encoding UTF8
}

# Chong chay trung 2 tien trinh. Mutex giu suot luc script chay, tien trinh
# thu 2 thay da co thi thoat ngay.
$Mutex = New-Object System.Threading.Mutex($false, "Global\TelegramVmStartListener")
if (-not $Mutex.WaitOne(0)) { exit }

function Invoke-Tg($Method, $BodyObj) {
    $json = $BodyObj | ConvertTo-Json -Depth 5 -Compress
    try {
        $r = Invoke-RestMethod -Uri "https://api.telegram.org/bot$BotToken/$Method" `
            -Method Post -ContentType "application/json" -Body $json `
            -TimeoutSec 10 -ErrorAction Stop
        return $r
    } catch {
        $detail = $_.ErrorDetails.Message
        if (-not $detail) { $detail = $_.Exception.Message }
        Write-Log "$Method LOI: $detail"
        return $null
    }
}

function Send-Telegram($Text) {
    $r = Invoke-Tg "sendMessage" @{ chat_id = $ChatId; text = $Text }
    return ($null -ne $r)
}

function Get-Vmrun() {
    foreach ($p in $VmrunPaths) {
        if (Test-Path $p) { return $p }
    }
    return $null
}

function Test-VmRunning($Vmrun, $VmxPath) {
    try {
        $out = & $Vmrun list 2>&1 | Out-String
        return ($out -match [regex]::Escape($VmxPath))
    } catch {
        Write-Log "vmrun list LOI: $($_.Exception.Message)"
        return $false
    }
}

# Ten file lua chon tren host, theo ten check (khoang trang -> gach ngang).
# Vd: "may ao 1" -> C:\Scripts\runchoice-may-ao-1.txt
function Get-RunChoiceHostPath($CheckName) {
    return "$ScriptDir\runchoice-$(Get-Slug $CheckName).txt"
}

# Ghi file lua chon len host roi copy vao trong khach. Tra ve $true neu
# copy duoc, $false neu khong (thieu $GuestUser/$GuestPass, VMware Tools
# trong khach chua len, hoac het $CopyTimeoutSec giay van copy khong duoc).
function Send-RunChoiceToGuest($Vmrun, $Vm, $CheckName, $Mode, $Acc) {
    if ($GuestUser -eq "" -or $GuestPass -eq "") {
        Write-Log "Copy runchoice ${CheckName}: chua dien `$GuestUser/`$GuestPass, khong copy duoc."
        return $false
    }
    $hostFile = Get-RunChoiceHostPath $CheckName
    "mode=$Mode" | Out-File -FilePath $hostFile -Encoding ascii -Force
    "acc=$Acc" | Out-File -FilePath $hostFile -Encoding ascii -Append
    Write-Log "Copy runchoice ${CheckName}: da ghi $hostFile (mode=$Mode acc=$Acc), dang copy vao khach..."
    $elapsed = 0
    while ($elapsed -le $CopyTimeoutSec) {
        $copyOut = & $Vmrun -T ws -gu $GuestUser -gp $GuestPass CopyFileFromHostToGuest "$($Vm.Path)" "$hostFile" "$RunChoiceGuestPath" 2>&1
        $copyCode = $LASTEXITCODE
        if ($copyCode -eq 0) {
            Write-Log "Copy runchoice ${CheckName}: OK sau ${elapsed} giay."
            return $true
        }
        Write-Log "Copy runchoice ${CheckName}: that bai (exit $copyCode) sau ${elapsed} giay: $($copyOut -join ' ')"
        if ($elapsed -ge $CopyTimeoutSec) { break }
        Start-Sleep -Seconds $CopyRetrySec
        $elapsed += $CopyRetrySec
    }
    Write-Log "Copy runchoice ${CheckName}: THAT BAI sau $CopyTimeoutSec giay, bo qua."
    return $false
}

function Start-Vm($Vmrun, $CheckName, $Vm, $Mode, $Acc) {
    $name = $Vm.Name
    $hasChoice = ($Mode -ne "" -and $Acc -ne "")
    $choiceText = ""
    if ($hasChoice) { $choiceText = " (che do $Mode, tai khoan $Acc)" }
    # May da chay roi thi bao lai, khong goi start nua, khong copy file.
    if (Test-VmRunning $Vmrun $Vm.Path) {
        Send-Telegram "May $CheckName ($name) dang chay roi, khong can mo lai."
        Write-Log "Nhan /movat $CheckName$choiceText : may da chay roi."
        return
    }
    Write-Log "Nhan /movat $CheckName$choiceText : dang mo $name ..."
    $startOut = ""
    try {
        $startOut = & $Vmrun -T ws start "$($Vm.Path)" nogui 2>&1 | Out-String
    } catch {
        $startOut = $_.Exception.Message
    }
    Write-Log "vmrun start $name : $startOut"
    if ($startOut -match "already in use") {
        Send-Telegram "Mo may $CheckName ($name) KHONG DUOC: file may ao dang bi khoa. Dong han cua so VMware Workstation tren May 1 roi bam nut Mo may ao lai."
        return
    }
    $copied = $false
    if ($hasChoice) {
        $copied = Send-RunChoiceToGuest $Vmrun $Vm $CheckName $Mode $Acc
    }
    Start-Sleep -Seconds $StartWaitSec
    if (Test-VmRunning $Vmrun $Vm.Path) {
        if ($hasChoice -and $copied) {
            Send-Telegram "Da mo may $CheckName ($name). Bot se chay che do $Mode voi tai khoan $Acc."
            Write-Log "Mo may $name THANH CONG (che do $Mode, tai khoan $Acc)."
        } elseif ($hasChoice) {
            Send-Telegram "Da mo may $CheckName ($name) NHUNG khong dua duoc lua chon vao trong may ao (chua dien tai khoan Windows khach trong listener, hoac VMware Tools trong may ao chua len). Bot se chay mac dinh che do 9 + tai khoan da luu. Kiem tra log C:\Scripts\vm-start-telegram.log tren May 1."
            Write-Log "Mo may $name THANH CONG nhung copy runchoice THAT BAI -> bot chay mac dinh che do 9."
        } else {
            Send-Telegram "Da mo may $CheckName ($name). Cho may ao khoi dong xong, bot se tu chay che do 9."
            Write-Log "Mo may $name THANH CONG."
        }
    } else {
        Send-Telegram "Mo may $CheckName ($name) THAT BAI: goi vmrun start khong bao loi nhung $StartWaitSec giay sau van khong thay may trong danh sach dang chay. Xem log C:\Scripts\vm-start-telegram.log"
        Write-Log "Mo may $name THAT BAI (khong thay trong vmrun list sau $StartWaitSec giay)."
    }
}

$Vmrun = Get-Vmrun
if (-not $Vmrun) {
    Write-Log "LOI: Khong tim thay vmrun.exe. Kiem tra duong dan VMware Workstation."
    exit 1
}
Write-Log "VM start listener khoi dong, vmrun=$Vmrun"
if ($GuestUser -eq "" -or $GuestPass -eq "") { Write-Log "CANH BAO: chua dien `$GuestUser/`$GuestPass o dau file -> khong dua duoc che do + tai khoan vao may ao, bot se chay theo ghi nho lan truoc." }

$Offset = 0
if (Test-Path $OffsetFile) {
    $saved = Get-Content $OffsetFile -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($saved -match '^\d+$') { $Offset = [int64]$saved }
}

while ($true) {
    try {
        # Lay lenh tu Worker (hang doi), khong dung getUpdates cua Telegram nua.
        $resp = Invoke-RestMethod -Uri "$QueueUrl/poll?since=$Offset" -Headers @{ "X-Poll-Key" = $PollKey } -TimeoutSec 15 -ErrorAction Stop

        foreach ($upd in $resp.result) {
            $Offset = [int64]$upd.update_id + 1
            $Offset | Out-File -FilePath $OffsetFile -Encoding ascii -Force

            if (-not $upd.message -or -not $upd.message.text) { continue }
            $txt = $upd.message.text.Trim()
            $who = $upd.message.from.id
            $chat = $upd.message.chat.id

            # Chi nhan lenh trong nhom MY PC, tu dung Tien.
            if ([string]$chat -ne [string]$ChatId) { continue }
            if ([string]$who -ne [string]$AllowedUserId) { continue }

            # Lenh tam ngung / tiep tuc RIENG theo tung may ao (v5).
            # BAT BUOC kem ten may ao: /tamngungvm may ao 1,
            # /tamngungvm may ao bu, /tieptucvm may ao 1, /tieptucvm may ao bu.
            # Lenh tran khong kem ten -> chi tra loi huong dan, KHONG lam gi.
            # Ten may sai -> chi tra loi huong dan, KHONG lam gi.
            if ($txt -match '^/(tamngungvm|tieptucvm)(@\w+)?$') {
                $cmd = $Matches[1]
                Send-Telegram "Lenh /$cmd can kem ten may ao: /$cmd may ao 1 hoac /$cmd may ao bu. Chi 2 may ao nay co tam ngung / tiep tuc rieng."
                Write-Log "Nhan /$cmd (khong kem ten may) : tra loi huong dan, khong lam gi."
                continue
            }
            if ($txt -match '^/(tamngungvm|tieptucvm)(@\w+)?\s+(.+)$') {
                $cmd = $Matches[1]
                $rest = $Matches[3].Trim()
                $rMode = ""
                $rAcc = ""
                # /tieptucvm co the kem che do + tai khoan: /tieptucvm may ao bu 9 valenline1998
                if ($cmd -eq "tieptucvm" -and $rest -match '^(.+?)\s+(10|[1-9])\s+(\S+)$') {
                    $target = $Matches[1].Trim()
                    $rMode = $Matches[2]
                    $rAcc = $Matches[3]
                } else {
                    $target = $rest
                }
                $key = ""
                foreach ($k in $Vms.Keys) {
                    if ($target.ToLower() -eq $k) { $key = $k; break }
                }
                if ($key -eq "") {
                    Send-Telegram "Ten may '$target' khong dung. Chi co 2 may ao: may ao 1, may ao bu. Vi du: /$cmd may ao bu"
                    Write-Log "Nhan /$cmd '$target' : ten may sai, tra loi huong dan, khong lam gi."
                    continue
                }
                $pauseFile = Get-PauseFilePath $key
                $vmName = $Vms[$key].Name
                if ($cmd -eq "tamngungvm") {
                    # Huy hen gio tu mo lai (neu dang cho sau Tiep tuc).
                    $PendingResume.Remove($key)
                    # Tam ngung rieng may nay: tao file pause rieng cua no.
                    # May nao dang chay van chay, khong bi tat.
                    if (Test-Path $pauseFile) {
                        Send-Telegram "May $key ($vmName) da tam ngung roi - watcher se khong tu mo lai may nay. May kia van theo doi binh thuong."
                        Write-Log "Nhan /tamngungvm $key : file pause rieng da co."
                    } else {
                        New-Item -Path $pauseFile -ItemType File -Force | Out-Null
                        Send-Telegram "Da tam ngung watcher cho may $key ($vmName). May nay tat se KHONG tu mo lai. May kia van theo doi binh thuong. May dang chay van chay - muon tat thi tat tay trong Workstation."
                        Write-Log "Nhan /tamngungvm $key : da tao file pause rieng $pauseFile."
                    }
                } else {
                    # Tiep tuc rieng may nay: xoa file pause rieng (neu co), roi hen gio.
                    # Sau $ResumeDelaySec giay, neu may dang tat thi listener tu mo lai.
                    $resumeChoiceText = ""
                    if ($rMode -ne "") { $resumeChoiceText = " Bot se chay che do $rMode, tai khoan $rAcc." }
                    if (Test-Path $pauseFile) {
                        Remove-Item $pauseFile -Force
                        Write-Log "Nhan /tieptucvm $key : da xoa file pause rieng $pauseFile."
                        Send-Telegram "Da tiep tuc may $key ($vmName). Neu may dang tat thi se tu mo lai sau $ResumeDelaySec giay.$resumeChoiceText"
                    } else {
                        Write-Log "Nhan /tieptucvm $key : khong co file pause rieng, van hen gio kiem tra."
                        Send-Telegram "May $key ($vmName) khong o trang thai tam ngung. Neu may dang tat thi se tu mo lai sau $ResumeDelaySec giay.$resumeChoiceText"
                    }
                    $PendingResume[$key] = @{ Due = (Get-Date).AddSeconds($ResumeDelaySec); Mode = $rMode; Acc = $rAcc }
                }
                continue
            }

            # Lenh /movat <ten may ao> [ <so che do 1-10> <tai khoan> ],
            # co the kem @ControlPCofTienbot. Ten may ao phai khop 1 trong
            # 2 ten check da biet O DAU chuoi (khong phan biet hoa/thuong).
            # Phan con lai: rong -> hanh vi cu (chi mo may, bot chay che
            # do 9 mac dinh); dung dang "<so 1-10> <1 tu>" -> che do +
            # tai khoan; dang khac -> ghi log roi bo qua.
            if ($txt -notmatch '^/movat(@\w+)?(\s+(.+))?$') { continue }
            $rest = ""
            if ($Matches[3]) { $rest = $Matches[3].Trim() }
            if ($rest -eq "") { continue }
            $key = ""
            $checkName = ""
            $remainder = ""
            foreach ($k in ($Vms.Keys | Sort-Object { $_.Length } -Descending)) {
                $kl = $k.Length
                if ($rest.Length -ge $kl -and $rest.Substring(0, $kl).ToLower() -eq $k) {
                    if ($rest.Length -eq $kl -or $rest[$kl] -eq ' ') {
                        $key = $k
                        $checkName = $rest.Substring(0, $kl)
                        $remainder = $rest.Substring($kl).Trim()
                        break
                    }
                }
            }
            if ($key -eq "") {
                Write-Log "Nhan /movat '$rest' : khong phai 1 trong 2 may ao, bo qua."
                continue
            }
            $mode = ""
            $acc = ""
            if ($remainder -ne "") {
                if ($remainder -match '^(10|[1-9])\s+(\S+)$') {
                    $mode = $Matches[1]
                    $acc = $Matches[2]
                } else {
                    Write-Log "Nhan /movat '$rest' : phan sau ten may khong dung dang '<so 1-10> <tai khoan>', bo qua."
                    continue
                }
            }
            Start-Vm $Vmrun $checkName $Vms[$key] $mode $acc
        }
    } catch {
        Write-Log "Poll LOI: $($_.Exception.Message)"
        Start-Sleep -Seconds 5
    }

    # Den gio tu mo lai sau Tiep tuc: chi mo neu van khong tam ngung va may dang tat.
    try {
        foreach ($k in @($PendingResume.Keys)) {
            $pr = $PendingResume[$k]
            if ((Get-Date) -lt $pr.Due) { continue }
            $PendingResume.Remove($k)
            if (Test-Path (Get-PauseFilePath $k)) {
                Write-Log "Het gio tieptucvm $k : dang tam ngung lai, khong mo."
                continue
            }
            if (Test-VmRunning $Vmrun $Vms[$k].Path) {
                Write-Log "Het gio tieptucvm $k : may dang chay, khong can mo."
                continue
            }
            Write-Log "Het $ResumeDelaySec giay sau tieptucvm $k : may dang tat, tu mo lai."
            Start-Vm $Vmrun $k $Vms[$k] $pr.Mode $pr.Acc
        }
    } catch {
        Write-Log "Resume LOI: $($_.Exception.Message)"
    }
    Start-Sleep -Seconds 15
}
'@
$files["watch-vmware-vm.ps1"] = @'
# Tu dong mo lai may ao VMware khi no tat - ho tro NHIEU may ao.
# v5 (13-11-2026): TAM NGUNG RIENG THEO TUNG MAY AO. Bo han file
# .pause chung cu (vm-autorestart.pause). Moi may ao co file tam
# ngung RIENG: C:\Scripts\vm-autorestart-may-ao-1.pause va
# C:\Scripts\vm-autorestart-may-ao-bu.pause (slug lay theo ten check:
# "may ao 1" -> may-ao-1, "may ao bu" -> may-ao-bu, giong listener).
# May nao co file pause rieng thi watcher BO QUA may do (khong tinh
# vao bo dem fail, khong thu mo), may con lai van tu mo lai binh thuong.
# Chay tren May 1 (DESKTOP-GLMQ72B, user TIEN), qua Startup, duoi user dang dang nhap.
# Cach hoat dong: cu moi $CheckSec giay, goi "vmrun list" 1 lan, doi chieu voi tung
# duong dan .vmx trong danh sach $Vms. May nao khong co trong danh sach dang chay
# thi goi "vmrun start" de mo lai. Neu nhieu may cung tat thi mo lech nhau
# $StaggerSec giay (mo xong 1 may moi mo may tiep theo) de tranh nang may chinh.
# Them may ao moi chi can them 1 dong vao $Vms (kem ten check de tinh file pause rieng).
# BAN ASCII, KHONG DAU, KHONG EMOJI.

# DANH SACH MAY AO CAN THEO DOI - sua o day.
# Moi dong la 1 may: Path = duong dan file .vmx, Name = ten de ghi log / bao Telegram,
# Check = ten check tren Healthchecks (khong phan biet hoa/thuong), dung de tinh
# file tam ngung rieng cua may do (slug: khoang trang -> gach ngang).
$Vms = @(
    @{ Path = "D:\win 10 CF 19H2 GHOST RELEASED\win 10.vmx"; Name = "TREO BU"; Check = "may ao bu" },
    @{ Path = "D:\MAY 1\May 1.vmx"; Name = "May 1"; Check = "may ao 1" }
)

$CheckSec = 120
$StartWaitSec = 30
$StaggerSec = 60   # 2 may cung tat thi mo lech nhau 60 giay, tranh nang may chinh luc khoi dong.
$GuiMode = "nogui"   # "nogui" = chay ngam, khong mo cua so Workstation. Doi thanh "gui" neu muon thay cua so.
$LogFile = "C:\Scripts\vm-autorestart.log"
# File tam ngung RIENG theo tung may ao (v5): "may ao 1" -> may-ao-1,
# "may ao bu" -> may-ao-bu. Khong con file .pause chung.
$PauseDir = "C:\Scripts"
$MaxFailBeforeBackoff = 5
$BackoffSec = 600

# Telegram: muon bao ve nhom MY PC thi dien token y het trong telegram-pc-status-7may.ps1.
# De trong thi tat bao Telegram, script van chay binh thuong, chi ghi log.
$BotToken = ""
$ChatId = "-5189532438"

$VmrunPaths = @(
    "C:\Program Files (x86)\VMware\VMware Workstation\vmrun.exe",
    "C:\Program Files\VMware\VMware Workstation\vmrun.exe"
)

function Write-Log($msg) {
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] $msg"
    try { Add-Content -Path $LogFile -Value $line -Encoding ascii } catch { }
    Write-Host $line
}

# Ten file tam ngung RIENG cua 1 may ao, theo ten check (khoang trang -> gach ngang).
# Vd: "may ao 1" -> C:\Scripts\vm-autorestart-may-ao-1.pause
function Get-PauseFilePath($CheckName) {
    $slug = $CheckName.ToLower() -replace '\s+', '-'
    return "$PauseDir\vm-autorestart-$slug.pause"
}

# File .pause chung cu (cac ban truoc v5): CHI dung de di chuyen 1 lan
# luc khoi dong, khong dung trong logic theo doi nua.
$LegacyPauseFile = "C:\Scripts\vm-autorestart.pause"

function Send-Telegram($text) {
    if ([string]::IsNullOrWhiteSpace($BotToken)) { return }
    if ($BotToken -eq ('PASTE_TOKEN' + '_HERE')) { return }
    try {
        $uri = "https://api.telegram.org/bot$BotToken/sendMessage"
        $body = @{ chat_id = $ChatId; text = $text }
        Invoke-RestMethod -Uri $uri -Method Post -Body $body -TimeoutSec 15 | Out-Null
    } catch {
        Write-Log "Telegram loi: $($_.Exception.Message)"
    }
}

# Chong chay trung 2 tien trinh (giong cac listener truoc).
$mutex = $null
$createdNew = $false
try {
    $mutex = New-Object System.Threading.Mutex($false, "Global\VmAutoRestartMayChuHaNoi", [ref]$createdNew)
    if (-not $createdNew) {
        Write-Host "Da co tien trinh khac dang chay, thoat."
        exit 0
    }
} catch {
    Write-Host "Khong tao duoc mutex, van chay tiep: $($_.Exception.Message)"
}

$Vmrun = $null
foreach ($p in $VmrunPaths) {
    if (Test-Path $p) { $Vmrun = $p; break }
}
if (-not $Vmrun) {
    Write-Log "LOI: Khong tim thay vmrun.exe. Kiem tra duong dan VMware Workstation, sua lai mang \$VmrunPaths."
    exit 1
}

# Loc danh sach: bo qua dong chua dien duong dan that, bao loi 1 lan roi van theo doi cac may con lai.
$VmsValid = @()
foreach ($vm in $Vms) {
    if ($vm.Path -match "THAY-DUONG-DAN") {
        Write-Log "BO QUA: May $($vm.Name) chua dien duong dan .vmx that, sua dong do trong `$Vms roi khoi dong lai watcher."
        continue
    }
    if (-not (Test-Path $vm.Path)) {
        Write-Log "BO QUA: Khong tim thay file .vmx: $($vm.Path) (may $($vm.Name))."
        continue
    }
    $VmsValid += $vm
}
if ($VmsValid.Count -eq 0) {
    Write-Log "LOI: Khong co may ao nao hop le trong danh sach. Dien duong dan .vmx that vao `$Vms roi chay lai."
    exit 1
}

# DI CHUYEN 1 LAN (v5): file .pause chung cu, neu con, doi thanh file
# pause RIENG cho tung may (giu nguyen y dinh "dang tam ngung" hien tai),
# roi xoa file chung. Sau buoc nay khong con file chung nao ca, khong
# co may nao tu mo lai ngoai y muon.
if (Test-Path $LegacyPauseFile) {
    foreach ($vm in $VmsValid) {
        $pf = Get-PauseFilePath $vm.Check
        if (-not (Test-Path $pf)) {
            New-Item -Path $pf -ItemType File -Force | Out-Null
            Write-Log "Di chuyen: file .pause chung cu -> tao file tam ngung rieng cho $($vm.Name): $pf"
        } else {
            Write-Log "Di chuyen: may $($vm.Name) da co file tam ngung rieng, giu nguyen: $pf"
        }
    }
    Remove-Item $LegacyPauseFile -Force
    Write-Log "Di chuyen: da xoa file .pause chung cu $LegacyPauseFile. Tu nay tam ngung rieng theo tung may."
}

$failCounts = @{}
$backoffUntil = @{}
foreach ($vm in $VmsValid) {
    $failCounts[$vm.Name] = 0
    $backoffUntil[$vm.Name] = [DateTime]::MinValue
}
$names = ($VmsValid | ForEach-Object { $_.Name }) -join ", "
Write-Log "Bat dau theo doi VM: $names, kiem tra moi $CheckSec giay, che do $GuiMode."
Send-Telegram "[VM] Da bat theo doi may ao tren May 1: $names, kiem tra moi $CheckSec giay."

# Trang thai tam ngung da ghi log (theo tung may), de chi ghi log khi
# trang thai tam ngung cua may do thay doi, khong spam moi vong.
$pausedLogged = @{}

while ($true) {
    # Tam ngung rieng theo tung may: may nao co file pause rieng thi chi
    # ghi log 1 lan khi trang thai doi, khong tinh vao bo dem fail,
    # khong thu mo. May khac van theo doi binh thuong.
    foreach ($vm in $VmsValid) {
        $pf = Get-PauseFilePath $vm.Check
        $isPaused = Test-Path $pf
        if ($isPaused -and -not $pausedLogged[$vm.Name]) {
            Write-Log "Tam dung: may $($vm.Name) co file tam ngung rieng $pf, se khong tu mo lai may nay cho den khi xoa file nay. May khac van theo doi binh thuong."
            $pausedLogged[$vm.Name] = $true
        } elseif (-not $isPaused -and $pausedLogged[$vm.Name]) {
            Write-Log "Tiep tuc: may $($vm.Name) da xoa file tam ngung rieng, theo doi lai binh thuong."
            $pausedLogged[$vm.Name] = $false
        }
    }

    $listOut = ""
    try {
        $listOut = & $Vmrun list 2>&1 | Out-String
    } catch {
        Write-Log "LOI khi goi vmrun list: $($_.Exception.Message)"
        Start-Sleep -Seconds $CheckSec
        continue
    }

    # Tim cac may dang tat, bo qua may dang tam ngung rieng va may dang
    # trong thoi gian nghi sau nhieu lan that bai.
    $now = Get-Date
    $toStart = @()
    foreach ($vm in $VmsValid) {
        if ($backoffUntil[$vm.Name] -gt $now) { continue }
        if (Test-Path (Get-PauseFilePath $vm.Check)) { continue }
        if ($listOut -notmatch [regex]::Escape($vm.Path)) { $toStart += $vm }
    }

    if ($toStart.Count -eq 0) {
        Start-Sleep -Seconds $CheckSec
        continue
    }

    # Mo lai tung may, lech nhau $StaggerSec giay neu co nhieu may cung tat.
    for ($i = 0; $i -lt $toStart.Count; $i++) {
        $vm = $toStart[$i]
        Write-Log "VM $($vm.Name) khong chay, dang mo lai (lan that bai lien tiep truoc do: $($failCounts[$vm.Name]))..."
        Send-Telegram "[VM] $($vm.Name) tren May 1 dang TAT, dang mo lai..."
        try {
            & $Vmrun -T ws start "$($vm.Path)" $GuiMode 2>&1 | Out-String | ForEach-Object { Write-Log "vmrun start $($vm.Name): $_" }
        } catch {
            Write-Log "LOI khi goi vmrun start cho $($vm.Name): $($_.Exception.Message)"
        }
        if ($i -lt ($toStart.Count - 1)) {
            Write-Log "Cho $StaggerSec giay truoc khi mo may tiep theo."
            Start-Sleep -Seconds $StaggerSec
        }
    }

    Start-Sleep -Seconds $StartWaitSec

    $listOut2 = ""
    try {
        $listOut2 = & $Vmrun list 2>&1 | Out-String
    } catch {
        Write-Log "LOI khi goi vmrun list sau khi start: $($_.Exception.Message)"
    }

    foreach ($vm in $toStart) {
        if ($listOut2 -match [regex]::Escape($vm.Path)) {
            Write-Log "OK: VM $($vm.Name) da chay lai."
            Send-Telegram "[VM] $($vm.Name) tren May 1 da mo lai."
            $failCounts[$vm.Name] = 0
        } else {
            $failCounts[$vm.Name]++
            Write-Log "LOI: Mo lai VM $($vm.Name) that bai (lan $($failCounts[$vm.Name]) lien tiep). Xem vmware.log trong thu muc VM de tim nguyen nhan."
            Send-Telegram "[VM] Mo lai $($vm.Name) tren May 1 THAT BAI (lan $($failCounts[$vm.Name])). Xem log C:\Scripts\vm-autorestart.log"
            if ($failCounts[$vm.Name] -ge $MaxFailBeforeBackoff) {
                $backoffUntil[$vm.Name] = (Get-Date).AddSeconds($BackoffSec)
                Write-Log "May $($vm.Name) that bai $($failCounts[$vm.Name]) lan lien tiep, nghi $BackoffSec giay truoc khi thu lai de tranh spam. May khac van theo doi binh thuong."
                $failCounts[$vm.Name] = 0
            }
        }
    }

    Start-Sleep -Seconds $CheckSec
}
'@
$files["setup-chay-bot.ps1"] = @'
# Cai chuc nang RUN: tao Task quyen cao nhat + tu chay listener khi dang nhap. Chay bang PowerShell admin.
$dst = "C:\Scripts"
$user = "$env:USERDOMAIN\$env:USERNAME"
$act = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$dst\chay-bot.ps1`""
$pr = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Highest
$set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Seconds 0)
Register-ScheduledTask -TaskName "ChayBotTheoLenh" -Action $act -Principal $pr -Settings $set -Force | Out-Null
Write-Host "OK: da tao Task ChayBotTheoLenh (quyen cao nhat)."
$bat = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\chay-bot-listener.bat"
"@echo off`r`npowershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$dst\chay-bot-listener.ps1`"" | Set-Content $bat -Encoding ascii
Start-Process $bat -WindowStyle Hidden
Write-Host "OK: da khoi dong listener RUN (tu chay moi lan dang nhap)."
'@
$files["setup-screenshot-listener.ps1"] = @'
# Cai dat listener chup man hinh - chay 1 lan tren MOI may can chup.
# KHONG can quyen Admin (chi ghi vao Startup cua user hien tai).
# Listener chay duoi user dang dang nhap, qua Startup, de chup duoc desktop.
# Neu chay duoi SYSTEM thi chup ra anh den, nen KHONG dung Task Scheduler SYSTEM.
# BAN ASCII, KHONG DAU, KHONG EMOJI.

$ScriptDir = "C:\Scripts"
$Listener = "$ScriptDir\telegram-screenshot-listener.ps1"
$StartupDir = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"
$Launcher = "$StartupDir\telegram-screenshot.bat"

if (-not (Test-Path $Listener)) {
    Write-Host "LOI: Khong thay $Listener"
    Write-Host "Copy file telegram-screenshot-listener.ps1 vao C:\Scripts\ truoc."
    exit 1
}

# Kiem tra da dien token + ten may chua.
$content = Get-Content $Listener -Raw
if ($content.Contains('PASTE_TOKEN' + '_HERE')) {
    Write-Host "LOI: Chua dien `$BotToken trong $Listener"
    Write-Host "Mo file bang Notepad, copy token y het trong telegram-pc-status-7may.ps1 roi chay lai."
    exit 1
}
if ($content -match 'THAY-TEN-MAY-NAY') {
    Write-Host "LOI: Chua dien `$MyName trong $Listener"
    Write-Host "Sua thanh ten may nay, giong het ten check tren Healthchecks, vi du: May chinh cty"
    exit 1
}

# Tao file bat trong Startup de listener tu chay moi lan dang nhap.
$bat = '@echo off' + [Environment]::NewLine +
    'start "" /min powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "C:\Scripts\telegram-screenshot-listener.ps1"' + [Environment]::NewLine
$bat | Out-File -FilePath $Launcher -Encoding ascii -Force
Write-Host "OK: Da tao $Launcher"

# Chay listener ngay, khong can dang xuat / khoi dong lai.
# Neu da chay roi thi tien trinh moi se tu thoat nho mutex trong script.
Start-Process -FilePath "powershell.exe" `
    -ArgumentList "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$Listener`"" `
    -WindowStyle Hidden
Start-Sleep -Seconds 5
Write-Host "OK: Da khoi dong listener. Doi 5 giay roi test:"
Write-Host "  Gui vao nhom MY PC: /chupmanhinh <ten may nay>"
Write-Host "  Anh man hinh phai ve nhom trong vong ~10 giay."
Write-Host "  Neu khong thay anh, mo file C:\Scripts\screenshot-telegram.log xem loi."
Write-Host "Ghi chu: de go listener, xoa file $Launcher roi khoi dong lai may."
'@
$files["setup-vm-start-listener.ps1"] = @'
# Cai dat listener mo may ao - chay 1 lan tren MAY 1 (DESKTOP-GLMQ72B).
# KHONG can quyen Admin (chi ghi vao Startup cua user hien tai).
# Listener chay duoi user dang dang nhap, qua Startup.
# KHONG dung Task Scheduler SYSTEM.
# BAN ASCII, KHONG DAU, KHONG EMOJI.

$ScriptDir = "C:\Scripts"
$Listener = "$ScriptDir\telegram-vm-start-listener.ps1"
$StartupDir = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"
$Launcher = "$StartupDir\telegram-vm-start.bat"

if (-not (Test-Path $Listener)) {
    Write-Host "LOI: Khong thay $Listener"
    Write-Host "Copy file telegram-vm-start-listener.ps1 vao C:\Scripts\ truoc."
    exit 1
}

# Kiem tra da dien token chua.
$content = Get-Content $Listener -Raw
if ($content.Contains('PASTE_TOKEN' + '_HERE')) {
    Write-Host "LOI: Chua dien `$BotToken trong $Listener"
    Write-Host "Mo file bang Notepad, copy token y het trong telegram-pc-status-7may.ps1 roi chay lai."
    exit 1
}

# Kiem tra da dien tai khoan Windows cua may ao chua (de copy file lua
# chon che do + tai khoan vao trong khach). Chi CANH BAO, khong chan:
# neu chua dien thi nut Mo may ao van mo duoc may, chi la bot se chay
# mac dinh che do 9 + tai khoan da luu.
if ($content.Contains('PASTE_GUEST_USER' + '_HERE') -or $content.Contains('PASTE_GUEST_PASS' + '_HERE')) {
    Write-Host "CANH BAO: Chua dien `$GuestUser / `$GuestPass trong $Listener"
    Write-Host "  Mo file bang Notepad, dien user/pass dang nhap Windows CUA MAY AO"
    Write-Host "  (ca 2 may ao dung chung 1 cap neu giong nhau). Neu de nguyen thi"
    Write-Host "  may ao van mo len binh thuong, nhung bot se chay mac dinh che do 9"
    Write-Host "  + tai khoan da luu, khong chay theo che do/tai khoan chon trong app."
    Write-Host "  Dien xong thi tat listener cu (Task Manager) roi chay lai file nay."
}

# Tao file bat trong Startup de listener tu chay moi lan dang nhap.
$bat = '@echo off' + [Environment]::NewLine +
    'start "" /min powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "C:\Scripts\telegram-vm-start-listener.ps1"' + [Environment]::NewLine
$bat | Out-File -FilePath $Launcher -Encoding ascii -Force
Write-Host "OK: Da tao $Launcher"

# Chay listener ngay, khong can dang xuat / khoi dong lai.
# Neu da chay roi thi tien trinh moi se tu thoat nho mutex trong script.
Start-Process -FilePath "powershell.exe" `
    -ArgumentList "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$Listener`"" `
    -WindowStyle Hidden
Start-Sleep -Seconds 5
Write-Host "OK: Da khoi dong listener. Doi 5 giay roi test:"
Write-Host "  Tat 1 may ao trong VMware Workstation (dong han cua so Workstation sau do),"
Write-Host "  roi trong app May cua Tien (v1.5) bam vao may ao do > chon che do + tai khoan"
Write-Host "  roi bam nut Mo may ao. Trong 30-60 giay Telegram bao ket qua ve nhom MY PC."
Write-Host "  Neu khong chon che do/tai khoan thi may van mo va bot chay mac dinh che do 9."
Write-Host "  Neu khong thay, mo file C:\Scripts\vm-start-telegram.log xem loi."
Write-Host "  Test tam ngung rieng (v1.5): bam Tam ngung trong chi tiet cua 1 may ao,"
Write-Host "  Telegram phai bao chi may do tam ngung; may kia van theo doi binh thuong."
Write-Host "Ghi chu: de go listener, xoa file $Launcher roi khoi dong lai May 1."
'@
$files["setup-vm-autorestart.ps1"] = @'
# Cai dat tu dong mo lai may ao VMware - chay 1 lan tren May 1.
# KHONG can quyen Admin (chi ghi vao Startup cua user hien tai).
# Watcher chay duoi user dang dang nhap, qua Startup, de vmrun thay duoc VM.
# BAN ASCII, KHONG DAU, KHONG EMOJI.

$ScriptDir = "C:\Scripts"
$Watcher = "$ScriptDir\watch-vmware-vm.ps1"
$StartupDir = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"
$Launcher = "$StartupDir\vm-autorestart.bat"

if (-not (Test-Path $Watcher)) {
    Write-Host "LOI: Khong thay $Watcher"
    Write-Host "Copy file watch-vmware-vm.ps1 vao C:\Scripts\ truoc."
    exit 1
}

# Kiem tra vmrun.exe co ton tai khong (chi canh bao, khong dung lai).
$found = $false
foreach ($p in @("C:\Program Files (x86)\VMware\VMware Workstation\vmrun.exe", "C:\Program Files\VMware\VMware Workstation\vmrun.exe")) {
    if (Test-Path $p) { $found = $true; Write-Host "OK: Tim thay vmrun.exe: $p" }
}
if (-not $found) {
    Write-Host "CANH BAO: Khong tim thay vmrun.exe o 2 duong dan mac dinh."
    Write-Host "Mo VMware Workstation, xem no cai o dau, roi sua mang VmrunPaths trong watch-vmware-vm.ps1."
}

# Nhac dien duong dan .vmx that vao danh sach $Vms trong watcher.
# Neu chua dien thi watcher se ghi log "BO QUA" va khong theo doi may nao.
$content = Get-Content $Watcher -Raw
if ($content -match 'THAY-DUONG-DAN') {
    Write-Host "CANH BAO: Trong watch-vmware-vm.ps1 van con dong placeholder THAY-DUONG-DAN."
    Write-Host "Mo file bang Notepad, dien duong dan file .vmx that + ten that cua 2 may ao vao danh sach `$Vms roi chay lai file setup nay."
}

# Tao file bat trong Startup de watcher tu chay moi lan dang nhap.
$bat = '@echo off' + [Environment]::NewLine +
    'start "" /min powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "C:\Scripts\watch-vmware-vm.ps1"' + [Environment]::NewLine
$bat | Out-File -FilePath $Launcher -Encoding ascii -Force
Write-Host "OK: Da tao $Launcher"

# Chay watcher ngay, khong can dang xuat / khoi dong lai.
# Neu da chay roi thi tien trinh moi se tu thoat nho mutex trong script.
Start-Process -FilePath "powershell.exe" `
    -ArgumentList "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$Watcher`"" `
    -WindowStyle Hidden
Start-Sleep -Seconds 5
Write-Host "OK: Da khoi dong watcher. Kiem tra log:"
Write-Host "  C:\Scripts\vm-autorestart.log"
Write-Host "Test: tat may ao trong VMware Workstation, doi toi da 120 giay + thoi gian khoi dong VM, may ao phai tu mo lai. Neu tat ca 2 may thi may thu hai mo sau may dau 60 giay."
Write-Host "Neu khong mo lai, mo file log tren xem loi vmrun."
Write-Host "Ghi chu (v5): tam ngung RIENG theo tung may:"
Write-Host "  May 1:   New-Item C:\Scripts\vm-autorestart-may-ao-1.pause"
Write-Host "  TREO BU: New-Item C:\Scripts\vm-autorestart-may-ao-bu.pause"
Write-Host "  Xoa file pause rieng cua may nao thi watcher mo lai may do."
Write-Host "  File .pause chung cu (neu con) watcher v5 tu doi thanh 2 file rieng tren khi khoi dong."
Write-Host "De go hoan toan, xoa file $Launcher roi khoi dong lai May 1 (hoac tat tien trinh powershell watch-vmware-vm.ps1 trong Task Manager)."
'@
$files["healthchecks-ping.ps1"] = @'
# healthchecks-ping.ps1 - Ping ngam ve Healthchecks.io (ASCII only, KHONG GUI TIN)
# Moi may co 1 URL ping RIENG, lay tu Healthchecks.io > check cua may do > Copy Ping URL.
# File nay CHI ping ngam, khong gui Telegram. Healthchecks se tu bao Telegram khi mat ping.
# Chay ngam moi 2 phut qua Task Scheduler (task Healthchecks-Heartbeat).

$PingUrl = "PASTE_PING_URL_HERE"

if ($PingUrl -eq "THAY-BANG-URL-RIENG-CUA-MAY-NAY" -or $PingUrl -eq "") {
    $Time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path "$env:TEMP\healthchecks-error.log" -Value "[$Time] Chua dien PingUrl - mo file nay bang Notepad va dan URL ping rieng cua may nay" -ErrorAction SilentlyContinue
    exit 1
}

try {
    Invoke-WebRequest -Uri $PingUrl -TimeoutSec 10 -UseBasicParsing -ErrorAction Stop | Out-Null
    exit 0
} catch {
    $Time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path "$env:TEMP\healthchecks-error.log" -Value "[$Time] Ping FAIL: $($_.Exception.Message)" -ErrorAction SilentlyContinue
    exit 1
}
'@
$files["setup-healthchecks.ps1"] = @'
# setup-healthchecks.ps1 - Doi task heartbeat Telegram sang ping ngam Healthchecks (ASCII only)
# Chay 1 lan tren moi may, bang PowerShell QUYEN ADMIN:
#   powershell -ExecutionPolicy Bypass -File "C:\Scripts\setup-healthchecks.ps1"
# No lam 2 viec:
#   1. Xoa task cu Telegram-PC-Heartbeat (gui tin [RUN] ve Telegram moi 5 phut - bo)
#   2. Tao task moi Healthchecks-Heartbeat (ping ngam ve Healthchecks moi 2 phut, khong gui tin)
# Task Telegram-PC-On va Telegram-PC-Off KHONG DOI - van bao [BAT]/[TAT] nhu cu.

$PingScript = "C:\Scripts\healthchecks-ping.ps1"

$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $IsAdmin) {
    Write-Host "LOI: Phai chay PowerShell bang Run as administrator roi chay lai file nay."
    exit 1
}

if (-not (Test-Path $PingScript)) {
    Write-Host "LOI: Khong thay file: $PingScript"
    Write-Host "Copy file healthchecks-ping.ps1 vao C:\Scripts\ truoc, dien URL ping rieng roi chay lai."
    exit 1
}

# 1. Xoa task heartbeat cu (neu khong co thi bao la da het, khong phai loi)
$OutDel = & schtasks.exe /delete /tn "Telegram-PC-Heartbeat" /f 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "OK: Da xoa Telegram-PC-Heartbeat cu"
} else {
    Write-Host "GHI CHU: Khong thay task Telegram-PC-Heartbeat cu (co the da xoa roi)"
}

# 2. Tao task ping ngam moi 2 phut, chay duoi SYSTEM de khong chop terminal (sua 13:43)
$Cmd = "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$PingScript`""
$Out = & schtasks.exe /create /tn "Healthchecks-Heartbeat" /tr $Cmd /sc minute /mo 2 /ru SYSTEM /rl highest /f 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "OK: Healthchecks-Heartbeat (ping ngam 2 phut/lan)"
} else {
    Write-Host "FAIL: Healthchecks-Heartbeat"
    Write-Host $Out
    exit 1
}

Write-Host ""
Write-Host "Kiem tra:"
schtasks.exe /query /tn "Telegram-PC-On" 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { Write-Host " - Co task Telegram-PC-On (bao BAT)" } else { Write-Host " - THIEU Telegram-PC-On" }
schtasks.exe /query /tn "Telegram-PC-Off" 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { Write-Host " - Co task Telegram-PC-Off (bao TAT)" } else { Write-Host " - THIEU Telegram-PC-Off" }
schtasks.exe /query /tn "Healthchecks-Heartbeat" 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { Write-Host " - Co task Healthchecks-Heartbeat (ping ngam)" } else { Write-Host " - THIEU Healthchecks-Heartbeat" }
schtasks.exe /query /tn "Telegram-PC-Heartbeat" 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { Write-Host " - CANH BAO: Van con task Telegram-PC-Heartbeat cu, can xoa tay" } else { Write-Host " - Da het task Telegram-PC-Heartbeat cu" }
'@
$files["telegram-pc-status-7may.ps1"] = @'
# Telegram PC On/Off - 7 may cua Tien (2026-11-10) - BAN ASCII, KHONG EMOJI
# Ly do: PowerShell 5.1 tren Windows doc file .ps1 theo ANSI neu khong co BOM,
# emoji + tieng Viet co dau se vo thanh ky tu rac va lam vo lenh. Ban nay chi
# dung ky tu ASCII nen chay duoc ngay, khong can doi encoding.
# Cach dung:
#   powershell -ExecutionPolicy Bypass -File "C:\Scripts\telegram-pc-status-7may.ps1" -Status On
#   powershell -ExecutionPolicy Bypass -File "C:\Scripts\telegram-pc-status-7may.ps1" -Status Off
#   powershell -ExecutionPolicy Bypass -File "C:\Scripts\telegram-pc-status-7may.ps1" -Status Heartbeat

param(
    [ValidateSet("On","Off","Heartbeat")]
    [string]$Status = "On"
)

$BotToken = "PASTE_TOKEN_HERE"
$ChatId   = "-5189532438"

# BANG DOI TEN: key = ten Windows that (chay `hostname` tren tung may de lay),
# value = ten goi cua Tien (viet khong dau de tranh loi encoding).
# Dien du 7 dong roi copy cung 1 file nay sang ca 7 may.
# May nao chua dien thi tin nhan se hien ten Windows that, van nhan ra duoc.
$NameMap = @{
    "DESKTOP-XXXX1" = "may chinh nha"
    "DESKTOP-XXXX2" = "may ao 1"
    "DESKTOP-XXXX3" = "may ao bu"
    "DESKTOP-ECF6V94" = "may phu nha"
    "DESKTOP-XXXX5" = "may chinh cty"
    "DESKTOP-XXXX6" = "may phu cty"
    "DESKTOP-XXXX7" = "laptop"
}

$Computer = $env:COMPUTERNAME
if ($NameMap.ContainsKey($Computer)) { $DisplayName = $NameMap[$Computer] }
else { $DisplayName = $Computer }

$User = $env:USERNAME
$Time = Get-Date -Format "dd/MM/yyyy HH:mm:ss"

try {
    $IP = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
        Where-Object { $_.IPAddress -notlike "169.*" -and $_.InterfaceAlias -notlike "*Loopback*" } |
        Select-Object -First 1 -ExpandProperty IPAddress)
} catch { $IP = "?" }

if ($Status -eq "On")        { $Icon = "[BAT]"; $TextStatus = "BAT" }
elseif ($Status -eq "Off")   { $Icon = "[TAT]"; $TextStatus = "TAT" }
else                         { $Icon = "[RUN]"; $TextStatus = "DANG CHAY (heartbeat)" }

$Message = "$Icon $DisplayName $TextStatus`nMay: $Computer`nUser: $User`nIP: $IP`nThoi gian: $Time"

for ($i = 1; $i -le 3; $i++) {
    try {
        Invoke-RestMethod -Uri "https://api.telegram.org/bot$BotToken/sendMessage" `
            -Method Post -Body @{ chat_id = $ChatId; text = $Message } `
            -TimeoutSec 10 -ErrorAction Stop
        Add-Content -Path "$PSScriptRoot\telegram-log.txt" -Value "[$Time] $Status OK - $DisplayName ($Computer)" -ErrorAction SilentlyContinue
        exit 0
    } catch {
        Start-Sleep -Seconds 3
    }
}
Add-Content -Path "$PSScriptRoot\telegram-log.txt" -Value "[$Time] $Status FAIL - $DisplayName ($Computer)" -ErrorAction SilentlyContinue
exit 1
'@

$files["setup-telegram-tasks.ps1"] = @'
# setup-telegram-tasks.ps1 - Tao 2 task bao BAT/TAT qua Telegram bang schtasks.exe (ASCII only)
# Gop tu setup-telegram-tasks-v2.ps1. BO phan Heartbeat vi setup-healthchecks.ps1 da xoa task do.
# Tu chay trong file CAI-may-*.ps1, hoac chay tay bang PowerShell QUYEN ADMIN:
#   powershell -ExecutionPolicy Bypass -File "C:\Scripts\setup-telegram-tasks.ps1"
# No tao:
#   Telegram-PC-On  : luc dang nhap, delay 30s, gui -Status On
#   Telegram-PC-Off : khi co event tat may 1074, gui -Status Off (neu that bai thi dung gpedit)

$ScriptPath = "C:\Scripts\telegram-pc-status-7may.ps1"

$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $IsAdmin) {
    Write-Host "LOI: Phai chay PowerShell bang Run as administrator roi chay lai file nay."
    exit 1
}

if (-not (Test-Path $ScriptPath)) {
    Write-Host "LOI: Khong thay file: $ScriptPath"
    exit 1
}

$Failed = $false

# On: onlogon + delay 30 giay
$CmdOn = "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ScriptPath`" -Status On"
$OutOn = & schtasks.exe /create /tn "Telegram-PC-On" /tr $CmdOn /sc onlogon /delay 0000:30 /rl highest /f 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "OK: Telegram-PC-On"
} else {
    Write-Host "FAIL: Telegram-PC-On"
    Write-Host $OutOn
    $Failed = $true
}

# Off: event System / User32 / 1074
$Query = "*[System[Provider[@Name='User32'] and EventID=1074]]"
$CmdOff = "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ScriptPath`" -Status Off"
$OutOff = & schtasks.exe /create /tn "Telegram-PC-Off" /tr $CmdOff /sc onevent /ec System /mo $Query /rl highest /f 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "OK: Telegram-PC-Off"
} else {
    Write-Host "FAIL: Telegram-PC-Off - dung gpedit thay the:"
    Write-Host "  gpedit.msc > Computer Configuration > Windows Settings > Scripts > Shutdown > Add"
    Write-Host "  Script: powershell.exe"
    Write-Host "  Parameters: -ExecutionPolicy Bypass -File `"$ScriptPath`" -Status Off"
    Write-Host $OutOff
    $Failed = $true
}

Write-Host ""
Write-Host "Kiem tra:"
schtasks.exe /query /tn "Telegram-PC-On" 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { Write-Host " - Co task Telegram-PC-On (bao BAT)" } else { Write-Host " - THIEU Telegram-PC-On" }
schtasks.exe /query /tn "Telegram-PC-Off" 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { Write-Host " - Co task Telegram-PC-Off (bao TAT)" } else { Write-Host " - THIEU Telegram-PC-Off (dung gpedit o tren)" }

if ($Failed) { exit 1 }
'@

foreach ($n in $files.Keys) {
    $s = $files[$n]
    $s = $s.Replace("PASTE_TOKEN_HERE", $token)
    $s = $s.Replace("PASTE_BOT_EXE_HERE", (Esc $botexe))
    $s = $s.Replace("PASTE_GUEST_USER_HERE", (Esc $gu)).Replace("PASTE_GUEST_PASS_HERE", (Esc $gp))
    $s = $s.Replace("PASTE_PING_URL_HERE", $pingurl)
    if ($n -eq "telegram-pc-status-7may.ps1") { $s = $s.Replace("DESKTOP-XXXX1", $env:COMPUTERNAME) }
    [IO.File]::WriteAllText("$dst\$n", $s, (New-Object Text.UTF8Encoding($false)))
    Write-Host "OK: da ghi $dst\$n"
}

Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
  Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -match 'telegram-screenshot-listener|chay-bot-listener|telegram-vm-start-listener|watch-vmware-vm' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Sleep 2
foreach ($setup in @("setup-chay-bot.ps1","setup-screenshot-listener.ps1","setup-vm-start-listener.ps1")) {
    Write-Host "Chay $setup ..."
    powershell -ExecutionPolicy Bypass -File "$dst\$setup"
}

Write-Host "Chay setup-telegram-tasks.ps1 ..."
powershell -ExecutionPolicy Bypass -File "$dst\setup-telegram-tasks.ps1"
if (-not $skipHc) {
    Write-Host "Chay setup-healthchecks.ps1 ..."
    powershell -ExecutionPolicy Bypass -File "$dst\setup-healthchecks.ps1"
}
if ($wat -eq "y") { powershell -ExecutionPolicy Bypass -File "$dst\setup-vm-autorestart.ps1" }
Write-Host ""
Write-Host "XONG may chinh nha. Vao web, bam Chup man hinh o 'May chinh nha' de thu (doi toi 30 giay)."
